import { useState } from 'react';
import { Search, Star, MapPin, Clock, DollarSign, Award, Filter, Users, Briefcase } from 'lucide-react';

interface TeamHubProps {
  user: any;
}

export function TeamHub({ user }: TeamHubProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedTalent, setSelectedTalent] = useState(null);

  const [talents] = useState([
    {
      id: '1',
      name: 'Sarah Chen',
      title: 'Senior Full-Stack Developer',
      avatar: 'SC',
      rating: 4.9,
      reviews: 127,
      location: 'San Francisco, CA',
      hourlyRate: 85,
      availability: 'Available',
      categories: ['development', 'backend'],
      skills: ['React', 'Node.js', 'TypeScript', 'PostgreSQL', 'AWS'],
      completedProjects: 89,
      responseTime: '< 1 hour',
      languages: ['English', 'Mandarin'],
      bio: 'Experienced full-stack developer with expertise in modern web technologies. Specialized in scalable applications and cloud architecture.',
      portfolio: [
        { title: 'E-commerce Platform', image: '🛒', tech: 'React, Node.js' },
        { title: 'SaaS Dashboard', image: '📊', tech: 'Vue.js, Python' },
        { title: 'Mobile Banking App', image: '💳', tech: 'React Native' }
      ],
      recentWork: ['E-commerce Platform Development', 'API Optimization Project', 'Database Migration']
    },
    {
      id: '2',
      name: 'Marcus Rivera',
      title: 'Creative UI/UX Designer',
      avatar: 'MR',
      rating: 4.8,
      reviews: 94,
      location: 'Austin, TX',
      hourlyRate: 75,
      availability: 'Busy',
      categories: ['design', 'ui-ux'],
      skills: ['Figma', 'Adobe Creative Suite', 'Prototyping', 'User Research', 'Branding'],
      completedProjects: 156,
      responseTime: '< 2 hours',
      languages: ['English', 'Spanish'],
      bio: 'Creative designer focused on user-centered design and modern interfaces. 8+ years creating digital experiences that users love.',
      portfolio: [
        { title: 'Fitness App Design', image: '🏃', tech: 'Figma, Principle' },
        { title: 'Brand Identity System', image: '🎨', tech: 'Adobe CC' },
        { title: 'Dashboard Redesign', image: '📱', tech: 'Sketch, InVision' }
      ],
      recentWork: ['Mobile App UI/UX Design', 'Brand Identity Project', 'Website Redesign']
    },
    {
      id: '3',
      name: 'Elena Rodriguez',
      title: 'Marketing Strategist',
      avatar: 'ER',
      rating: 5.0,
      reviews: 73,
      location: 'Miami, FL',
      hourlyRate: 90,
      availability: 'Available',
      categories: ['marketing', 'strategy'],
      skills: ['Digital Marketing', 'Content Strategy', 'SEO', 'Social Media', 'Analytics'],
      completedProjects: 67,
      responseTime: '< 30 minutes',
      languages: ['English', 'Spanish', 'Portuguese'],
      bio: 'Results-driven marketing strategist with proven track record in growth marketing and brand development across multiple industries.',
      portfolio: [
        { title: 'SaaS Growth Campaign', image: '📈', tech: 'Google Ads, Analytics' },
        { title: 'Content Marketing System', image: '📝', tech: 'HubSpot, SEMrush' },
        { title: 'Social Media Strategy', image: '📱', tech: 'Meta, LinkedIn' }
      ],
      recentWork: ['Brand Marketing Strategy', 'Content Campaign', 'Growth Optimization']
    },
    {
      id: '4',
      name: 'Alex Kim',
      title: 'Backend Specialist',
      avatar: 'AK',
      rating: 4.7,
      reviews: 45,
      location: 'Seattle, WA',
      hourlyRate: 80,
      availability: 'Available',
      categories: ['development', 'backend'],
      skills: ['Python', 'Django', 'PostgreSQL', 'Redis', 'Docker', 'Kubernetes'],
      completedProjects: 34,
      responseTime: '< 1 hour',
      languages: ['English', 'Korean'],
      bio: 'Backend engineer specializing in scalable architectures and high-performance systems. Expert in cloud infrastructure and DevOps.',
      portfolio: [
        { title: 'Microservices Architecture', image: '⚙️', tech: 'Python, Docker' },
        { title: 'Real-time Chat System', image: '💬', tech: 'WebSocket, Redis' },
        { title: 'Data Pipeline', image: '🔄', tech: 'Apache Kafka' }
      ],
      recentWork: ['API Development', 'Database Optimization', 'Cloud Migration']
    }
  ]);

  const categories = [
    { id: 'all', label: 'All Talent', count: talents.length },
    { id: 'development', label: 'Development', count: talents.filter(t => t.categories.includes('development')).length },
    { id: 'design', label: 'Design', count: talents.filter(t => t.categories.includes('design')).length },
    { id: 'marketing', label: 'Marketing', count: talents.filter(t => t.categories.includes('marketing')).length },
    { id: 'strategy', label: 'Strategy', count: talents.filter(t => t.categories.includes('strategy')).length }
  ];

  const getAvailabilityColor = (availability: string) => {
    switch (availability) {
      case 'Available': return 'text-green-400 bg-green-400/10';
      case 'Busy': return 'text-yellow-400 bg-yellow-400/10';
      case 'Unavailable': return 'text-red-400 bg-red-400/10';
      default: return 'text-gray-400 bg-gray-400/10';
    }
  };

  const filteredTalents = talents.filter(talent => {
    const matchesSearch = talent.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         talent.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         talent.skills.some(skill => skill.toLowerCase().includes(searchQuery.toLowerCase()));
    const matchesCategory = selectedCategory === 'all' || talent.categories.includes(selectedCategory);
    return matchesSearch && matchesCategory;
  });

  if (selectedTalent) {
    return (
      <div className="min-h-screen px-6 py-8">
        <div className="max-w-4xl mx-auto">
          <button
            onClick={() => setSelectedTalent(null)}
            className="text-cyan-400 hover:text-cyan-300 mb-6 flex items-center gap-2"
          >
            ← Back to Team
          </button>
          
          {/* Talent Profile */}
          <div className="bg-neutral-900/50 border border-neutral-800 rounded-2xl p-8">
            <div className="flex items-start gap-6 mb-8">
              <div className="w-20 h-20 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-2xl flex items-center justify-center">
                <span className="text-2xl font-bold text-white">{selectedTalent.avatar}</span>
              </div>
              
              <div className="flex-1">
                <h1 className="text-2xl font-bold text-white mb-2">{selectedTalent.name}</h1>
                <p className="text-xl text-gray-300 mb-4">{selectedTalent.title}</p>
                
                <div className="flex items-center gap-6 mb-4">
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span className="font-medium text-white">{selectedTalent.rating}</span>
                    <span className="text-gray-400">({selectedTalent.reviews} reviews)</span>
                  </div>
                  
                  <div className="flex items-center gap-1 text-gray-400">
                    <MapPin className="w-4 h-4" />
                    {selectedTalent.location}
                  </div>
                  
                  <span className={`px-3 py-1 rounded-full text-sm ${getAvailabilityColor(selectedTalent.availability)}`}>
                    {selectedTalent.availability}
                  </span>
                </div>
                
                <p className="text-gray-300 leading-relaxed">{selectedTalent.bio}</p>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="font-bold text-white mb-4">Skills & Expertise</h3>
                <div className="flex flex-wrap gap-2 mb-6">
                  {selectedTalent.skills.map((skill, index) => (
                    <span key={index} className="bg-neutral-800 text-gray-300 px-3 py-1 rounded-full text-sm">
                      {skill}
                    </span>
                  ))}
                </div>
                
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Rate</span>
                    <span className="text-white font-medium">
                      ${selectedTalent.hourlyRate}/hr
                      <span className="text-xs text-gray-400 ml-1">
                        (≈0.03 ETH)
                      </span>
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Response Time</span>
                    <span className="text-white font-medium">{selectedTalent.responseTime}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Projects Completed</span>
                    <span className="text-white font-medium">{selectedTalent.completedProjects}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">Languages</span>
                    <span className="text-white font-medium">{selectedTalent.languages.join(', ')}</span>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="font-bold text-white mb-4">Recent Work</h3>
                <div className="space-y-3">
                  {selectedTalent.recentWork.map((work, index) => (
                    <div key={index} className="bg-neutral-800 p-3 rounded-lg">
                      <span className="text-gray-300">{work}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            
            <div className="mt-8 pt-8 border-t border-neutral-800 flex gap-4">
              <button className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-medium py-3 px-8 rounded-full transition-all duration-300">
                Start Collaboration
              </button>
              <button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-medium py-3 px-8 rounded-full transition-all duration-300 flex items-center gap-2">
                💎 Smart Contract
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen px-6 py-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-white mb-2">Team Hub</h1>
          <p className="text-gray-400">Discover and connect with our elite talent network</p>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search talent by name, skills, or expertise..."
              className="w-full pl-12 pr-4 py-3 bg-neutral-900/50 border border-neutral-700 rounded-xl text-white placeholder-gray-400 focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
            />
          </div>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap gap-3 mb-8">
          {categories.map((category) => (
            <button
              key={category.id}
              onClick={() => setSelectedCategory(category.id)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                selectedCategory === category.id
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white'
                  : 'bg-neutral-800 text-gray-400 hover:text-white hover:bg-neutral-700'
              }`}
            >
              {category.label} ({category.count})
            </button>
          ))}
        </div>

        {/* Talent Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTalents.map((talent) => (
            <div
              key={talent.id}
              onClick={() => setSelectedTalent(talent)}
              className="bg-neutral-900/50 border border-neutral-800 rounded-2xl p-6 hover:border-neutral-700 transition-all cursor-pointer group"
            >
              <div className="flex items-start gap-4 mb-4">
                <div className="w-14 h-14 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-xl flex items-center justify-center">
                  <span className="text-lg font-bold text-white">{talent.avatar}</span>
                </div>
                
                <div className="flex-1">
                  <h3 className="font-bold text-white group-hover:text-cyan-400 transition-colors mb-1">
                    {talent.name}
                  </h3>
                  <p className="text-gray-400 text-sm mb-2">{talent.title}</p>
                  
                  <div className="flex items-center gap-3 text-xs">
                    <div className="flex items-center gap-1">
                      <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                      <span className="text-white">{talent.rating}</span>
                    </div>
                    <span className="text-gray-500">({talent.reviews})</span>
                    <span className={`px-2 py-1 rounded-full ${getAvailabilityColor(talent.availability)}`}>
                      {talent.availability}
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex flex-wrap gap-1 mb-4">
                {talent.skills.slice(0, 4).map((skill, index) => (
                  <span key={index} className="bg-neutral-800 text-gray-400 px-2 py-1 rounded text-xs">
                    {skill}
                  </span>
                ))}
                {talent.skills.length > 4 && (
                  <span className="text-gray-500 text-xs px-2 py-1">
                    +{talent.skills.length - 4} more
                  </span>
                )}
              </div>

              <div className="flex justify-between items-center pt-4 border-t border-neutral-800">
                <div className="flex items-center gap-4 text-sm text-gray-400">
                  <div className="flex items-center gap-1">
                    <DollarSign className="w-3 h-3" />
                    ${talent.hourlyRate}/hr
                  </div>
                  <div className="text-xs text-purple-300">
                    💎 0.03 ETH
                  </div>
                  <div className="flex items-center gap-1">
                    <Briefcase className="w-3 h-3" />
                    {talent.completedProjects}
                  </div>
                </div>
                
                <div className="flex items-center gap-1 text-xs text-gray-400">
                  <Clock className="w-3 h-3" />
                  {talent.responseTime}
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredTalents.length === 0 && (
          <div className="text-center py-16">
            <div className="w-16 h-16 bg-neutral-800 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="font-bold text-white mb-2">No talent found</h3>
            <p className="text-gray-400">Try adjusting your search criteria or explore different categories</p>
          </div>
        )}
      </div>
    </div>
  );
}