import { useState } from 'react';
import { Plus, MessageCircle, Clock, CheckCircle, AlertCircle, Filter, Search } from 'lucide-react';
import { AdvancedChat } from './AdvancedChat';

interface RecentTicketsProps {
  user: any;
  onNewChat: () => void;
}

export function RecentTickets({ user, onNewChat }: RecentTicketsProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('all');
  const [selectedTicket, setSelectedTicket] = useState(null);

  const [tickets] = useState([
    {
      id: '1',
      name: 'ticket_001',
      title: 'E-commerce Platform Development',
      description: 'Need a modern e-commerce platform with React, Node.js, and payment integration',
      status: 'active',
      category: 'development',
      budget: '3 ETH (~$7.5K)',
      timeline: '2-3 months',
      offers: 12,
      messages: 24,
      lastActivity: new Date(Date.now() - 300000),
      talent: {
        name: 'Sarah Chen',
        avatar: 'SC',
        rating: 4.9
      }
    },
    {
      id: '2',
      name: 'ticket_002',
      title: 'Mobile App UI/UX Design',
      description: 'Design a fitness tracking app with modern, clean interface',
      status: 'in-progress',
      category: 'design',
      budget: '1.2 ETH (~$3K)',
      timeline: '1 month',
      offers: 8,
      messages: 15,
      lastActivity: new Date(Date.now() - 900000),
      talent: {
        name: 'Marcus Rivera',
        avatar: 'MR',
        rating: 4.8
      }
    },
    {
      id: '3',
      name: 'ticket_003',
      title: 'Brand Identity & Marketing Strategy',
      description: 'Complete brand package including logo, guidelines, and go-to-market strategy',
      status: 'completed',
      category: 'marketing',
      budget: '8 ETH (~$20K)',
      timeline: '3-6 months',
      offers: 6,
      messages: 42,
      lastActivity: new Date(Date.now() - 3600000),
      talent: {
        name: 'Elena Rodriguez',
        avatar: 'ER',
        rating: 5.0
      }
    },
    {
      id: '4',
      name: 'ticket_004',
      title: 'Product Demo Video',
      description: 'Create a professional product demonstration video for SaaS platform',
      status: 'pending',
      category: 'video',
      budget: '0.8 ETH (~$2K)',
      timeline: '1-2 weeks',
      offers: 15,
      messages: 3,
      lastActivity: new Date(Date.now() - 7200000),
      talent: null
    }
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'text-cyan-400 bg-cyan-400/10 border-cyan-400/30';
      case 'in-progress': return 'text-blue-400 bg-blue-400/10 border-blue-400/30';
      case 'completed': return 'text-green-400 bg-green-400/10 border-green-400/30';
      case 'pending': return 'text-orange-400 bg-orange-400/10 border-orange-400/30';
      default: return 'text-gray-400 bg-gray-400/10 border-gray-400/30';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'active': return <Clock className="w-3 h-3" />;
      case 'in-progress': return <AlertCircle className="w-3 h-3" />;
      case 'completed': return <CheckCircle className="w-3 h-3" />;
      case 'pending': return <Clock className="w-3 h-3" />;
      default: return <Clock className="w-3 h-3" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'design': return 'from-pink-500 to-rose-500';
      case 'development': return 'from-blue-500 to-cyan-500';
      case 'marketing': return 'from-green-500 to-emerald-500';
      case 'video': return 'from-purple-500 to-violet-500';
      case 'biz': return 'from-orange-500 to-amber-500';
      default: return 'from-gray-500 to-gray-600';
    }
  };

  const formatTimeAgo = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    
    if (hours > 0) return `${hours}h ago`;
    return `${minutes}m ago`;
  };

  const filteredTickets = tickets.filter(ticket => {
    const matchesSearch = ticket.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         ticket.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = selectedStatus === 'all' || ticket.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  if (selectedTicket) {
    return (
      <AdvancedChat 
        ticket={selectedTicket} 
        user={user} 
        onBack={() => setSelectedTicket(null)} 
      />
    );
  }

  return (
    <div className="min-h-screen px-6 py-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold text-white mb-2">Jobs</h1>
            <p className="text-gray-400">Manage your project tickets and collaborations</p>
          </div>
          <button
            onClick={onNewChat}
            className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-medium py-3 px-6 rounded-full transition-all duration-300 flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            New Project
          </button>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search tickets..."
              className="w-full pl-12 pr-4 py-3 bg-neutral-900/50 border border-neutral-700 rounded-xl text-white placeholder-gray-400 focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
            />
          </div>
          
          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="px-4 py-3 bg-neutral-900/50 border border-neutral-700 rounded-xl text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
          >
            <option value="all">All Status</option>
            <option value="active">Active</option>
            <option value="in-progress">In Progress</option>
            <option value="completed">Completed</option>
            <option value="pending">Pending</option>
          </select>
        </div>

        {/* Tickets Grid */}
        <div className="grid gap-6">
          {filteredTickets.map((ticket) => (
            <div
              key={ticket.id}
              onClick={() => setSelectedTicket(ticket)}
              className="bg-neutral-900/50 border border-neutral-800 rounded-2xl p-6 hover:border-neutral-700 transition-all cursor-pointer group"
            >
              <div className="flex justify-between items-start mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <div className={`w-3 h-3 rounded-full bg-gradient-to-r ${getCategoryColor(ticket.category)}`}></div>
                    <h3 className="font-bold text-white group-hover:text-cyan-400 transition-colors">
                      {ticket.title}
                    </h3>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(ticket.status)} flex items-center gap-1`}>
                      {getStatusIcon(ticket.status)}
                      {ticket.status.replace('-', ' ')}
                    </span>
                  </div>
                  
                  <p className="text-gray-400 text-sm mb-3 line-clamp-2">
                    {ticket.description}
                  </p>
                  
                  <div className="flex items-center gap-4 text-xs text-gray-500">
                    <span>#{ticket.name}</span>
                    <span>{ticket.budget}</span>
                    <span>{ticket.timeline}</span>
                  </div>
                </div>

                {ticket.talent && (
                  <div className="flex items-center gap-2 ml-4">
                    <div className="w-8 h-8 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full flex items-center justify-center">
                      <span className="text-xs font-bold text-white">{ticket.talent.avatar}</span>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium text-white">{ticket.talent.name}</div>
                      <div className="text-xs text-gray-400">★ {ticket.talent.rating}</div>
                    </div>
                  </div>
                )}
              </div>

              <div className="flex justify-between items-center pt-4 border-t border-neutral-800">
                <div className="flex items-center gap-4 text-sm text-gray-400">
                  <div className="flex items-center gap-1">
                    <MessageCircle className="w-4 h-4" />
                    {ticket.messages}
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="text-cyan-400">{ticket.offers}</span> offers
                  </div>
                </div>
                
                <div className="text-sm text-gray-400">
                  {formatTimeAgo(ticket.lastActivity)}
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredTickets.length === 0 && (
          <div className="text-center py-16">
            <div className="w-16 h-16 bg-neutral-800 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="font-bold text-white mb-2">No tickets found</h3>
            <p className="text-gray-400 mb-6">
              {searchQuery || selectedStatus !== 'all' 
                ? 'Try adjusting your search or filters' 
                : 'Create your first project to get started'
              }
            </p>
          </div>
        )}
      </div>
    </div>
  );
}