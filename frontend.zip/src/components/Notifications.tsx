import { useState, useEffect } from 'react';
import { Bell, X, CheckCircle, AlertCircle, MessageCircle, DollarSign } from 'lucide-react';

interface NotificationsProps {
  user: any;
}

export function Notifications({ user }: NotificationsProps) {
  const [notifications, setNotifications] = useState([]);
  const [showNotifications, setShowNotifications] = useState(false);

  useEffect(() => {
    if (!user) {
      setNotifications([]);
      return;
    }

    // Mock notifications based on user type
    const mockNotifications = [
      {
        id: '1',
        type: 'offer',
        title: 'New Project Offer',
        message: 'You received a new offer for "E-commerce Platform" - $2,500',
        timestamp: new Date(Date.now() - 300000), // 5 minutes ago
        read: false,
        icon: DollarSign,
        color: 'text-green-400'
      },
      {
        id: '2',
        type: 'message',
        title: 'New Message',
        message: 'Sarah sent you a message in "Mobile App UI/UX"',
        timestamp: new Date(Date.now() - 900000), // 15 minutes ago
        read: false,
        icon: MessageCircle,
        color: 'text-blue-400'
      },
      {
        id: '3',
        type: 'project',
        title: 'Project Update',
        message: 'Your project "Data Analytics Dashboard" has been completed',
        timestamp: new Date(Date.now() - 3600000), // 1 hour ago
        read: true,
        icon: CheckCircle,
        color: 'text-green-400'
      }
    ];

    // Filter notifications based on user type
    if (user.isTalent) {
      setNotifications(mockNotifications);
    } else {
      setNotifications(mockNotifications.filter(n => n.type !== 'offer'));
    }
  }, [user]);

  const unreadCount = notifications.filter(n => !n.read).length;

  const markAsRead = (notificationId) => {
    setNotifications(prev => 
      prev.map(n => 
        n.id === notificationId ? { ...n, read: true } : n
      )
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(n => ({ ...n, read: true }))
    );
  };

  const removeNotification = (notificationId) => {
    setNotifications(prev => prev.filter(n => n.id !== notificationId));
  };

  const formatTimeAgo = (timestamp) => {
    const now = new Date();
    const diff = now.getTime() - timestamp.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    if (minutes > 0) return `${minutes}m ago`;
    return 'Just now';
  };

  if (!user) return null;

  return (
    <div className="relative">
      {/* Notification Banner for Important Updates */}
      {user.isTalent && unreadCount > 0 && (
        <div className="w-full bg-gradient-to-r from-orange-600 to-pink-600 text-white px-6 py-3 font-medium flex items-center justify-center">
          <Bell className="w-5 h-5 mr-2" />
          You have {unreadCount} new notification{unreadCount > 1 ? 's' : ''}
          <button
            onClick={() => setShowNotifications(true)}
            className="ml-4 bg-white/20 hover:bg-white/30 px-3 py-1 rounded-full text-sm transition-colors"
          >
            View
          </button>
        </div>
      )}

      {/* Notification Dropdown */}
      {showNotifications && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-start justify-center z-50 pt-20">
          <div className="bg-neutral-900 rounded-xl border border-neutral-800 shadow-2xl max-w-md w-full mx-4 max-h-[80vh] overflow-hidden">
            <div className="p-4 border-b border-neutral-800 flex justify-between items-center">
              <h3 className="font-bold text-white flex items-center gap-2">
                <Bell className="w-5 h-5" />
                Notifications
                {unreadCount > 0 && (
                  <span className="bg-orange-500 text-white text-xs px-2 py-1 rounded-full">
                    {unreadCount}
                  </span>
                )}
              </h3>
              <div className="flex items-center gap-2">
                {unreadCount > 0 && (
                  <button
                    onClick={markAllAsRead}
                    className="text-orange-500 hover:text-orange-400 text-sm"
                  >
                    Mark all read
                  </button>
                )}
                <button
                  onClick={() => setShowNotifications(false)}
                  className="text-gray-400 hover:text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="max-h-96 overflow-y-auto">
              {notifications.length === 0 ? (
                <div className="p-8 text-center">
                  <Bell className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-400">No notifications yet</p>
                </div>
              ) : (
                <div className="space-y-1">
                  {notifications.map((notification) => {
                    const IconComponent = notification.icon;
                    return (
                      <div
                        key={notification.id}
                        className={`p-4 hover:bg-neutral-800 transition-colors cursor-pointer ${
                          !notification.read ? 'bg-neutral-800/50' : ''
                        }`}
                        onClick={() => markAsRead(notification.id)}
                      >
                        <div className="flex items-start gap-3">
                          <div className={`w-8 h-8 rounded-full bg-neutral-700 flex items-center justify-center ${notification.color}`}>
                            <IconComponent className="w-4 h-4" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex justify-between items-start mb-1">
                              <h4 className={`font-medium ${!notification.read ? 'text-white' : 'text-gray-300'}`}>
                                {notification.title}
                              </h4>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  removeNotification(notification.id);
                                }}
                                className="text-gray-500 hover:text-gray-300 ml-2"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                            <p className="text-gray-400 text-sm mb-1">{notification.message}</p>
                            <div className="flex justify-between items-center">
                              <span className="text-xs text-gray-500">
                                {formatTimeAgo(notification.timestamp)}
                              </span>
                              {!notification.read && (
                                <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}