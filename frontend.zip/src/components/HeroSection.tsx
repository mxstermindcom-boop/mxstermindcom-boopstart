import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { ArrowRight, Play } from "lucide-react";

export function HeroSection() {
  return (
    <section className="pt-20 pb-16 px-4">
      <div className="container mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <Badge variant="secondary" className="w-fit">
              Interactive Design Made Simple
            </Badge>
            
            <h1 className="text-4xl lg:text-5xl tracking-tight">
              Master Figma Prototyping
              <span className="text-primary block">in 10 Minutes</span>
            </h1>
            
            <p className="text-xl text-muted-foreground leading-relaxed">
              Transform static frames into interactive, clickable experiences. 
              Learn to create prototypes that validate ideas fast without writing code.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" className="group">
                Start Tutorial
                <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </Button>
              <Button variant="outline" size="lg" className="group">
                <Play className="mr-2 h-4 w-4" />
                Watch Demo
              </Button>
            </div>

            <div className="flex items-center gap-8 pt-4">
              <div>
                <div className="text-2xl font-semibold">10 min</div>
                <div className="text-sm text-muted-foreground">To master basics</div>
              </div>
              <div className="w-px h-8 bg-border"></div>
              <div>
                <div className="text-2xl font-semibold">Free</div>
                <div className="text-sm text-muted-foreground">Built-in tool</div>
              </div>
              <div className="w-px h-8 bg-border"></div>
              <div>
                <div className="text-2xl font-semibold">No Code</div>
                <div className="text-sm text-muted-foreground">Required</div>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-accent/30 rounded-2xl blur-3xl -z-10"></div>
            <ImageWithFallback
              src="https://images.unsplash.com/photo-1618761714954-0b8cd0026356?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaWdtYSUyMGRlc2lnbiUyMGludGVyZmFjZXxlbnwxfHx8fDE3NTkzMzI3NTV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
              alt="Figma design interface"
              className="w-full h-auto rounded-2xl shadow-2xl"
            />
          </div>
        </div>
      </div>
    </section>
  );
}