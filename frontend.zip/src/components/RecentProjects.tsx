import { useState } from 'react';
import { Plus, MessageCircle, Clock, CheckCircle, AlertCircle } from 'lucide-react';
import { TicketChat } from './TicketChat';

interface RecentProjectsProps {
  user: any;
}

export function RecentProjects({ user }: RecentProjectsProps) {
  const [projects, setProjects] = useState([
    {
      id: '1',
      name: 'ticket_1',
      title: 'E-commerce Platform',
      description: 'Build a modern e-commerce platform with React and Node.js',
      status: 'active',
      messages: [
        { role: 'user', text: 'I need help building an e-commerce platform', timestamp: new Date(Date.now() - 3600000) },
        { role: 'ai', text: 'I can help you with that! Let me break down the requirements and create a development plan.', timestamp: new Date(Date.now() - 3500000) },
        { role: 'team', text: 'Hello! I\'m Sarah, a full-stack developer. I\'d love to work on this project with you.', timestamp: new Date(Date.now() - 3000000) }
      ],
      createdAt: new Date(Date.now() - 86400000)
    },
    {
      id: '2',
      name: 'ticket_2',
      title: 'Mobile App UI/UX',
      description: 'Design and develop a mobile app interface for fitness tracking',
      status: 'in-progress',
      messages: [
        { role: 'user', text: 'Looking for UI/UX design for a fitness app', timestamp: new Date(Date.now() - 7200000) },
        { role: 'ai', text: 'Great! I can help you create wireframes and design specifications.', timestamp: new Date(Date.now() - 7000000) }
      ],
      createdAt: new Date(Date.now() - 172800000)
    },
    {
      id: '3',
      name: 'ticket_3',
      title: 'Data Analytics Dashboard',
      description: 'Create a real-time analytics dashboard for business metrics',
      status: 'completed',
      messages: [
        { role: 'user', text: 'Need a dashboard for business analytics', timestamp: new Date(Date.now() - 259200000) },
        { role: 'team', text: 'Perfect! I specialize in data visualization. Let\'s get started!', timestamp: new Date(Date.now() - 259000000) }
      ],
      createdAt: new Date(Date.now() - 259200000)
    }
  ]);

  const [showCreateForm, setShowCreateForm] = useState(false);
  const [newProject, setNewProject] = useState({ title: '', description: '' });

  const handleCreateProject = (e) => {
    e.preventDefault();
    if (!newProject.title || !newProject.description) return;

    const project = {
      id: Date.now().toString(),
      name: `ticket_${projects.length + 1}`,
      title: newProject.title,
      description: newProject.description,
      status: 'active',
      messages: [
        { 
          role: 'user', 
          text: newProject.description, 
          timestamp: new Date() 
        },
        { 
          role: 'ai', 
          text: 'Thank you for creating this project! I\'m analyzing your requirements and will connect you with the best talent for this job.', 
          timestamp: new Date(Date.now() + 5000) 
        }
      ],
      createdAt: new Date()
    };

    setProjects([project, ...projects]);
    setNewProject({ title: '', description: '' });
    setShowCreateForm(false);
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'active':
        return <Clock className="w-4 h-4 text-orange-500" />;
      case 'in-progress':
        return <AlertCircle className="w-4 h-4 text-blue-500" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      default:
        return <Clock className="w-4 h-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'active':
        return 'text-orange-500 bg-orange-500/10';
      case 'in-progress':
        return 'text-blue-500 bg-blue-500/10';
      case 'completed':
        return 'text-green-500 bg-green-500/10';
      default:
        return 'text-gray-500 bg-gray-500/10';
    }
  };

  return (
    <section>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-white">Recent Projects</h2>
        <button
          onClick={() => setShowCreateForm(!showCreateForm)}
          className="bg-gradient-to-r from-orange-500 to-pink-600 hover:from-orange-600 hover:to-pink-700 text-white font-medium py-2 px-4 rounded-full transition-all duration-300 flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          New Project
        </button>
      </div>

      {showCreateForm && (
        <form
          onSubmit={handleCreateProject}
          className="mb-6 bg-neutral-900 rounded-xl p-6 border border-neutral-800"
        >
          <h3 className="font-bold text-white mb-4">Start a New Project</h3>
          <div className="space-y-4">
            <input
              type="text"
              value={newProject.title}
              onChange={(e) => setNewProject({ ...newProject, title: e.target.value })}
              placeholder="Project Title"
              className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-lg text-white placeholder-gray-400 focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              required
            />
            <textarea
              value={newProject.description}
              onChange={(e) => setNewProject({ ...newProject, description: e.target.value })}
              placeholder="Describe your project requirements in detail..."
              rows={4}
              className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-lg text-white placeholder-gray-400 focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
              required
            />
            <div className="flex gap-3">
              <button
                type="submit"
                className="bg-orange-500 hover:bg-orange-600 text-white font-medium py-2 px-6 rounded-full transition-colors"
              >
                Create Project
              </button>
              <button
                type="button"
                onClick={() => setShowCreateForm(false)}
                className="bg-neutral-700 hover:bg-neutral-600 text-white font-medium py-2 px-6 rounded-full transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        </form>
      )}

      <div className="space-y-6">
        {projects.map((project) => (
          <div key={project.id} className="bg-neutral-900 rounded-xl border border-neutral-800 overflow-hidden">
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-bold text-white">{project.title}</h3>
                    <div className={`px-2 py-1 rounded-full text-xs font-medium flex items-center gap-1 ${getStatusColor(project.status)}`}>
                      {getStatusIcon(project.status)}
                      {project.status}
                    </div>
                  </div>
                  <p className="text-gray-400 mb-2">{project.description}</p>
                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    <span>#{project.name}</span>
                    <span>Created {project.createdAt.toLocaleDateString()}</span>
                    <div className="flex items-center gap-1">
                      <MessageCircle className="w-4 h-4" />
                      {project.messages.length} messages
                    </div>
                  </div>
                </div>
              </div>
              
              <TicketChat project={project} user={user} />
            </div>
          </div>
        ))}
      </div>

      {projects.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-neutral-800 rounded-full flex items-center justify-center mx-auto mb-4">
            <Plus className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-xl font-bold text-white mb-2">No Projects Yet</h3>
          <p className="text-gray-400 mb-6">Create your first project to get started with our expert team.</p>
          <button
            onClick={() => setShowCreateForm(true)}
            className="bg-gradient-to-r from-orange-500 to-pink-600 hover:from-orange-600 hover:to-pink-700 text-white font-medium py-3 px-6 rounded-full transition-all duration-300"
          >
            Create Your First Project
          </button>
        </div>
      )}
    </section>
  );
}