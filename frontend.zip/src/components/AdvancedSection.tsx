import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { 
  Sparkles, 
  Zap, 
  RotateCcw, 
  Smartphone,
  ExternalLink,
  ArrowUpRight
} from "lucide-react";

export function AdvancedSection() {
  const features = [
    {
      icon: Sparkles,
      title: "Smart Animate",
      description: "Auto-animates layer changes between frames for smooth transitions.",
      example: "Button hover states, loading animations, smooth page transitions",
      level: "Intermediate"
    },
    {
      icon: Zap,
      title: "Variables & Conditionals",
      description: "Create dynamic states and conditional logic in your prototypes.",
      example: "Show/hide elements based on user role, toggle dark mode, dynamic content",
      level: "Advanced"
    },
    {
      icon: RotateCcw,
      title: "Overflow Scrolling",
      description: "Enable scrolling for content that extends beyond frame boundaries.",
      example: "Long lists, content feeds, navigation menus, chat interfaces",
      level: "Beginner"
    },
    {
      icon: Smartphone,
      title: "Device Frames",
      description: "Preview prototypes in realistic device contexts for better testing.",
      example: "Mobile apps, responsive web designs, tablet interfaces",
      level: "Beginner"
    }
  ];

  return (
    <section id="advanced" className="py-16 px-4 bg-muted/30">
      <div className="container mx-auto">
        <div className="text-center space-y-4 mb-12">
          <Badge variant="outline" className="mb-2">
            Advanced Features
          </Badge>
          <h2 className="text-3xl lg:text-4xl">
            Take Your Prototypes
            <span className="text-primary block">to the Next Level</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Master advanced prototyping techniques to create more realistic and engaging user experiences.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 items-start">
          <div className="space-y-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="group hover:shadow-lg transition-all duration-300">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                          <Icon className="h-5 w-5 text-primary" />
                        </div>
                        <div>
                          <CardTitle className="text-lg">{feature.title}</CardTitle>
                          <Badge 
                            variant={feature.level === 'Advanced' ? 'destructive' : feature.level === 'Intermediate' ? 'default' : 'secondary'}
                            className="mt-1"
                          >
                            {feature.level}
                          </Badge>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm">
                        <ExternalLink className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-3">{feature.description}</p>
                    <div className="bg-muted/50 rounded-lg p-3">
                      <p className="text-sm">
                        <span className="font-medium">Example uses: </span>
                        {feature.example}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <div className="lg:sticky lg:top-24">
            <Card className="overflow-hidden">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  Advanced Prototype Demo
                  <ArrowUpRight className="h-4 w-4" />
                </CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1586296221759-909c8bb73c5b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1aSUyMHV4JTIwcHJvdG90eXBpbmd8ZW58MXx8fHwxNzU5MzYyMjg4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Advanced prototyping example"
                  className="w-full h-64 object-cover"
                />
                <div className="p-6 space-y-4">
                  <p className="text-muted-foreground">
                    See how advanced features like Smart Animate and Variables work together 
                    to create sophisticated, app-like interactions.
                  </p>
                  <Button className="w-full">
                    View Live Demo
                    <ExternalLink className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}