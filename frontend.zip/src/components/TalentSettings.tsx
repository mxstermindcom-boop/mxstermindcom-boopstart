import { useState } from 'react';
import { Settings, Star, Award, DollarSign } from 'lucide-react';

interface TalentSettingsProps {
  user: any;
}

export function TalentSettings({ user }: TalentSettingsProps) {
  const [profile, setProfile] = useState({
    name: user.name || '',
    title: 'Full-Stack Developer',
    skills: 'React, Node.js, TypeScript, Python, MongoDB',
    bio: 'Passionate developer with 5+ years of experience building scalable web applications.',
    hourlyRate: 75,
    availability: 'Available',
    portfolio: 'https://portfolio.example.com'
  });

  const [isEditing, setIsEditing] = useState(false);

  const handleSave = (e) => {
    e.preventDefault();
    // In a real app, this would save to backend
    setIsEditing(false);
  };

  if (!user.isTalent) {
    return (
      <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800">
        <div className="text-center">
          <Award className="w-12 h-12 text-orange-500 mx-auto mb-4" />
          <h3 className="font-bold text-white mb-2">Become a Talent</h3>
          <p className="text-gray-400 mb-4">
            Join our elite network of pre-vetted professionals and start earning from your expertise.
          </p>
          <button className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 text-white font-medium py-2 px-6 rounded-full transition-all duration-300">
            Apply to Join
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Talent Profile */}
      <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800">
        <div className="flex justify-between items-center mb-6">
          <h3 className="font-bold text-white flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Talent Profile
          </h3>
          <button
            onClick={() => setIsEditing(!isEditing)}
            className="text-orange-500 hover:text-orange-400 font-medium"
          >
            {isEditing ? 'Cancel' : 'Edit'}
          </button>
        </div>

        {isEditing ? (
          <form onSubmit={handleSave} className="space-y-4">
            <input
              type="text"
              value={profile.name}
              onChange={(e) => setProfile({ ...profile, name: e.target.value })}
              placeholder="Your Name"
              className="w-full px-4 py-2 bg-neutral-800 border border-neutral-700 rounded-lg text-white placeholder-gray-400"
            />
            <input
              type="text"
              value={profile.title}
              onChange={(e) => setProfile({ ...profile, title: e.target.value })}
              placeholder="Professional Title"
              className="w-full px-4 py-2 bg-neutral-800 border border-neutral-700 rounded-lg text-white placeholder-gray-400"
            />
            <input
              type="text"
              value={profile.skills}
              onChange={(e) => setProfile({ ...profile, skills: e.target.value })}
              placeholder="Skills (comma separated)"
              className="w-full px-4 py-2 bg-neutral-800 border border-neutral-700 rounded-lg text-white placeholder-gray-400"
            />
            <textarea
              value={profile.bio}
              onChange={(e) => setProfile({ ...profile, bio: e.target.value })}
              placeholder="Professional Bio"
              rows={3}
              className="w-full px-4 py-2 bg-neutral-800 border border-neutral-700 rounded-lg text-white placeholder-gray-400 resize-none"
            />
            <div className="grid grid-cols-2 gap-4">
              <input
                type="number"
                value={profile.hourlyRate}
                onChange={(e) => setProfile({ ...profile, hourlyRate: parseInt(e.target.value) })}
                placeholder="Hourly Rate ($)"
                className="px-4 py-2 bg-neutral-800 border border-neutral-700 rounded-lg text-white placeholder-gray-400"
              />
              <select
                value={profile.availability}
                onChange={(e) => setProfile({ ...profile, availability: e.target.value })}
                className="px-4 py-2 bg-neutral-800 border border-neutral-700 rounded-lg text-white"
              >
                <option value="Available">Available</option>
                <option value="Busy">Busy</option>
                <option value="Unavailable">Unavailable</option>
              </select>
            </div>
            <button
              type="submit"
              className="bg-orange-500 hover:bg-orange-600 text-white font-medium py-2 px-6 rounded-full transition-colors"
            >
              Save Changes
            </button>
          </form>
        ) : (
          <div className="space-y-4">
            <div>
              <h4 className="font-medium text-white">{profile.name}</h4>
              <p className="text-orange-400">{profile.title}</p>
            </div>
            
            <div>
              <p className="text-sm text-gray-400 mb-1">Skills</p>
              <div className="flex flex-wrap gap-2">
                {profile.skills.split(', ').map((skill, index) => (
                  <span
                    key={index}
                    className="bg-neutral-800 text-gray-300 px-2 py-1 rounded text-xs"
                  >
                    {skill}
                  </span>
                ))}
              </div>
            </div>

            <div>
              <p className="text-sm text-gray-400 mb-1">Bio</p>
              <p className="text-gray-300 text-sm">{profile.bio}</p>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-2">
              <div>
                <p className="text-sm text-gray-400">Rate</p>
                <p className="text-white font-medium flex items-center gap-1">
                  <DollarSign className="w-4 h-4" />
                  {profile.hourlyRate}/hr
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-400">Status</p>
                <span className={`inline-flex items-center gap-1 text-sm font-medium ${
                  profile.availability === 'Available' ? 'text-green-400' :
                  profile.availability === 'Busy' ? 'text-yellow-400' : 'text-red-400'
                }`}>
                  <div className={`w-2 h-2 rounded-full ${
                    profile.availability === 'Available' ? 'bg-green-400' :
                    profile.availability === 'Busy' ? 'bg-yellow-400' : 'bg-red-400'
                  }`}></div>
                  {profile.availability}
                </span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Performance Stats */}
      <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800">
        <h3 className="font-bold text-white mb-4 flex items-center gap-2">
          <Star className="w-5 h-5" />
          Performance
        </h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-orange-500 mb-1">4.9</div>
            <div className="text-sm text-gray-400">Rating</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-500 mb-1">23</div>
            <div className="text-sm text-gray-400">Projects</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-500 mb-1">98%</div>
            <div className="text-sm text-gray-400">Success Rate</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-500 mb-1">$12.5k</div>
            <div className="text-sm text-gray-400">Earned</div>
          </div>
        </div>
      </div>

      {/* Recent Offers */}
      <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800">
        <h3 className="font-bold text-white mb-4">Recent Offers</h3>
        <div className="space-y-3">
          <div className="bg-neutral-800 p-4 rounded-lg border border-neutral-700">
            <div className="flex justify-between items-start mb-2">
              <h4 className="font-medium text-white">Mobile App Development</h4>
              <span className="text-green-400 font-medium">$2,500</span>
            </div>
            <p className="text-gray-400 text-sm mb-3">
              Looking for React Native developer for fitness tracking app...
            </p>
            <div className="flex gap-2">
              <button className="bg-orange-500 hover:bg-orange-600 text-white text-sm px-4 py-2 rounded-full">
                Accept
              </button>
              <button className="bg-neutral-700 hover:bg-neutral-600 text-white text-sm px-4 py-2 rounded-full">
                Decline
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}