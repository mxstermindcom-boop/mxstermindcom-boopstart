import { useState, useEffect } from 'react';
import { RecentProjects } from './RecentProjects';
import { TalentSettings } from './TalentSettings';
import { AuthModal } from './AuthModal';

interface DashboardProps {
  user: any;
}

export function Dashboard({ user }: DashboardProps) {
  const [showAuthModal, setShowAuthModal] = useState(false);

  useEffect(() => {
    if (!user) {
      setShowAuthModal(true);
    }
  }, [user]);

  if (!user) {
    return (
      <div className="min-h-screen bg-neutral-950 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-orange-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-400">Loading dashboard...</p>
        </div>
        {showAuthModal && (
          <AuthModal 
            onClose={() => setShowAuthModal(false)}
            onAuthSuccess={() => setShowAuthModal(false)}
          />
        )}
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-950">
      <div className="max-w-6xl mx-auto py-12 px-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">
            Welcome back, {user.name}!
          </h1>
          <p className="text-gray-400">
            Manage your projects and collaborate with the best talent in the industry.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <RecentProjects user={user} />
          </div>
          
          <div className="space-y-6">
            {user.isTalent && <TalentSettings user={user} />}
            
            {/* Quick Stats */}
            <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800">
              <h3 className="font-bold text-white mb-4">Quick Stats</h3>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-400">Active Projects</span>
                  <span className="text-white font-medium">3</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Total Projects</span>
                  <span className="text-white font-medium">12</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Success Rate</span>
                  <span className="text-green-400 font-medium">94%</span>
                </div>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-neutral-900 rounded-xl p-6 border border-neutral-800">
              <h3 className="font-bold text-white mb-4">Recent Activity</h3>
              <div className="space-y-3 text-sm">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <span className="text-gray-400">Project "E-commerce Platform" completed</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                  <span className="text-gray-400">New message in "Mobile App"</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                  <span className="text-gray-400">Talent proposal received</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}