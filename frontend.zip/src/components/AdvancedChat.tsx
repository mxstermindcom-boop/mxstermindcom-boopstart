import { useState, useRef, useEffect } from 'react';
import { ArrowLeft, Send, Bot, User, Users, Paperclip, Smile, MoreVertical, Star } from 'lucide-react';

interface AdvancedChatProps {
  ticket: any;
  user: any;
  onBack: () => void;
}

export function AdvancedChat({ ticket, user, onBack }: AdvancedChatProps) {
  const [messages, setMessages] = useState([
    {
      id: '1',
      role: 'user',
      text: ticket.description,
      timestamp: new Date(Date.now() - 3600000),
      sender: user.name
    },
    {
      id: '2',
      role: 'ai',
      text: "I've analyzed your project requirements. This looks like an excellent opportunity! I'm connecting you with our top-rated developers who specialize in e-commerce platforms. Let me break down the technical approach we'd recommend...",
      timestamp: new Date(Date.now() - 3500000),
      sender: 'AI Assistant'
    },
    {
      id: '3',
      role: 'team',
      text: "Hi! I'm Sarah, a full-stack developer with 6+ years of experience in e-commerce platforms. I've built similar projects using React, Node.js, and Stripe integration. I'd love to discuss your specific requirements and provide a detailed proposal.",
      timestamp: new Date(Date.now() - 3000000),
      sender: ticket.talent?.name || 'Sarah Chen'
    },
    {
      id: '4',
      role: 'user',
      text: "That sounds great! I'm particularly interested in the payment integration and inventory management features. What's your approach to handling real-time stock updates?",
      timestamp: new Date(Date.now() - 2500000),
      sender: user.name
    },
    {
      id: '5',
      role: 'team',
      text: "Excellent question! For real-time inventory management, I'd implement WebSocket connections for live updates, Redis for caching frequently accessed data, and event-driven architecture to handle stock changes across multiple channels simultaneously.",
      timestamp: new Date(Date.now() - 2000000),
      sender: ticket.talent?.name || 'Sarah Chen'
    }
  ]);

  const [newMessage, setNewMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    const userMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: newMessage,
      timestamp: new Date(),
      sender: user.name
    };

    setMessages(prev => [...prev, userMessage]);
    setNewMessage('');
    setIsTyping(true);

    // Simulate AI/team response
    setTimeout(() => {
      const isAI = Math.random() > 0.6;
      const response = {
        id: (Date.now() + 1).toString(),
        role: isAI ? 'ai' : 'team',
        text: isAI 
          ? generateAIResponse(newMessage)
          : generateTeamResponse(newMessage),
        timestamp: new Date(),
        sender: isAI ? 'AI Assistant' : (ticket.talent?.name || 'Sarah Chen')
      };
      setMessages(prev => [...prev, response]);
      setIsTyping(false);
    }, 1000 + Math.random() * 2000);
  };

  const generateAIResponse = (userMessage) => {
    const responses = [
      "That's a great insight! Let me analyze the technical requirements and suggest the best approach for your specific use case.",
      "I understand your concerns. Based on similar projects, here are some recommendations that could optimize your workflow.",
      "Excellent point! I'll coordinate with the development team to ensure we address this properly in the implementation.",
      "I can help facilitate this discussion. Let me connect you with additional specialists if needed.",
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  };

  const generateTeamResponse = (userMessage) => {
    const responses = [
      "Absolutely! I have experience implementing similar features. Let me walk you through my approach and show you some examples from previous projects.",
      "That's definitely achievable within your timeline and budget. I'd recommend starting with an MVP approach and then iterating based on user feedback.",
      "Great question! I've solved similar challenges before. The key is to design a scalable architecture from the start.",
      "I'd be happy to create a detailed technical specification for this. When would be a good time for a quick call to discuss the details?",
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  };

  const getRoleIcon = (role) => {
    switch (role) {
      case 'ai':
        return <Bot className="w-4 h-4" />;
      case 'team':
        return <Users className="w-4 h-4" />;
      default:
        return <User className="w-4 h-4" />;
    }
  };

  const getRoleColor = (role) => {
    switch (role) {
      case 'ai':
        return 'text-pink-400';
      case 'team':
        return 'text-purple-400';
      default:
        return 'text-cyan-400';
    }
  };

  const getRoleBackground = (role) => {
    switch (role) {
      case 'ai':
        return 'bg-pink-500/10 border-pink-500/20';
      case 'team':
        return 'bg-purple-500/10 border-purple-500/20';
      default:
        return 'bg-cyan-500/10 border-cyan-500/20';
    }
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <div className="bg-neutral-900/50 border-b border-neutral-800 px-6 py-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={onBack}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
            
            <div className="flex items-center gap-3">
              <div className={`w-3 h-3 rounded-full bg-gradient-to-r from-blue-500 to-cyan-500`}></div>
              <div>
                <h2 className="font-bold text-white">{ticket.title}</h2>
                <p className="text-sm text-gray-400">#{ticket.name} • {ticket.budget} • {ticket.timeline}</p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-4">
            {ticket.talent && (
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                  <span className="text-xs font-bold text-white">{ticket.talent.avatar}</span>
                </div>
                <div>
                  <div className="text-sm font-medium text-white">{ticket.talent.name}</div>
                  <div className="text-xs text-gray-400 flex items-center gap-1">
                    <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
                    {ticket.talent.rating}
                  </div>
                </div>
              </div>
            )}
            
            <button className="text-gray-400 hover:text-white transition-colors">
              <MoreVertical className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 px-6 py-6 overflow-y-auto">
        <div className="max-w-4xl mx-auto space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-3 ${message.role === 'user' ? 'flex-row-reverse' : ''}`}
            >
              <div className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${getRoleBackground(message.role)}`}>
                <span className={getRoleColor(message.role)}>
                  {getRoleIcon(message.role)}
                </span>
              </div>
              
              <div className={`flex-1 max-w-2xl ${message.role === 'user' ? 'text-right' : ''}`}>
                <div className="flex items-center gap-2 mb-2">
                  <span className={`text-sm font-medium ${getRoleColor(message.role)}`}>
                    {message.sender}
                  </span>
                  <span className="text-xs text-gray-500">
                    {message.timestamp.toLocaleTimeString()}
                  </span>
                </div>
                
                <div className={`inline-block px-4 py-3 rounded-2xl ${
                  message.role === 'user' 
                    ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white' 
                    : 'bg-neutral-800 text-gray-200 border border-neutral-700'
                }`}>
                  <p className="text-sm leading-relaxed">{message.text}</p>
                </div>
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex gap-3">
              <div className="w-10 h-10 bg-pink-500/10 border border-pink-500/20 rounded-full flex items-center justify-center">
                <Bot className="w-4 h-4 text-pink-400" />
              </div>
              <div className="bg-neutral-800 border border-neutral-700 rounded-2xl px-4 py-3">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Message Input */}
      <div className="bg-neutral-900/50 border-t border-neutral-800 px-6 py-4">
        <div className="max-w-4xl mx-auto">
          <form onSubmit={handleSendMessage} className="flex items-end gap-3">
            <div className="flex-1 relative">
              <textarea
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                placeholder="Type your message..."
                rows={1}
                className="w-full px-4 py-3 pr-20 bg-neutral-800 border border-neutral-700 rounded-2xl text-white placeholder-gray-400 focus:ring-2 focus:ring-cyan-500 focus:border-transparent resize-none"
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage(e);
                  }
                }}
              />
              
              <div className="absolute right-2 bottom-2 flex items-center gap-1">
                <button
                  type="button"
                  className="text-gray-400 hover:text-white p-1.5 rounded-lg transition-colors"
                >
                  <Paperclip className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  className="text-gray-400 hover:text-white p-1.5 rounded-lg transition-colors"
                >
                  <Smile className="w-4 h-4" />
                </button>
              </div>
            </div>
            
            <button
              type="submit"
              disabled={!newMessage.trim()}
              className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 disabled:opacity-50 disabled:cursor-not-allowed text-white p-3 rounded-2xl transition-all duration-300"
            >
              <Send className="w-5 h-5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}