import { useState } from 'react';
import { User, Settings, Bell, CreditCard, Shield, Globe, Smartphone, Mail, Wallet, Copy } from 'lucide-react';
import { CryptoWallet } from './CryptoWallet';

interface ProfileSettingsProps {
  user: any;
}

export function ProfileSettings({ user }: ProfileSettingsProps) {
  const [activeTab, setActiveTab] = useState('profile');
  const [profile, setProfile] = useState({
    name: user?.name || 'Demo User',
    email: user?.email || 'demo@mxstermind.com',
    phone: '+1 (555) 123-4567',
    location: 'San Francisco, CA',
    timezone: 'PST (UTC-8)',
    bio: 'Entrepreneur passionate about building innovative solutions.',
    company: 'Startup Inc.',
    website: 'https://example.com'
  });

  const [notifications, setNotifications] = useState({
    projectUpdates: true,
    newOffers: true,
    messages: true,
    marketing: false,
    weeklyDigest: true
  });

  const [paymentMethods] = useState([
    { id: '1', type: 'card', last4: '4242', brand: 'Visa', default: false },
    { id: '2', type: 'card', last4: '5555', brand: 'Mastercard', default: false },
    { id: '3', type: 'crypto', address: '0x742d35Cc...56789', currency: 'ETH', balance: '2.45', default: true },
    { id: '4', type: 'crypto', address: '0x742d35Cc...56789', currency: 'USDC', balance: '12,450', default: false }
  ]);

  const tabs = [
    { id: 'profile', label: 'Profile', icon: User },
    { id: 'notifications', label: 'Notifications', icon: Bell },
    { id: 'payments', label: 'Payments', icon: CreditCard },
    { id: 'security', label: 'Security', icon: Shield }
  ];

  const handleSave = (section) => {
    // Simulate saving
    console.log(`Saving ${section}...`);
  };

  const renderProfile = () => (
    <div className="space-y-6">
      <div>
        <h3 className="font-bold text-white mb-4">Personal Information</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-gray-300 mb-2">Full Name</label>
            <input
              type="text"
              value={profile.name}
              onChange={(e) => setProfile({ ...profile, name: e.target.value })}
              className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-xl text-white"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-300 mb-2">Email</label>
            <input
              type="email"
              value={profile.email}
              onChange={(e) => setProfile({ ...profile, email: e.target.value })}
              className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-xl text-white"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-300 mb-2">Phone</label>
            <input
              type="tel"
              value={profile.phone}
              onChange={(e) => setProfile({ ...profile, phone: e.target.value })}
              className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-xl text-white"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-300 mb-2">Location</label>
            <input
              type="text"
              value={profile.location}
              onChange={(e) => setProfile({ ...profile, location: e.target.value })}
              className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-xl text-white"
            />
          </div>
        </div>
      </div>

      <div>
        <label className="block text-sm text-gray-300 mb-2">Bio</label>
        <textarea
          value={profile.bio}
          onChange={(e) => setProfile({ ...profile, bio: e.target.value })}
          rows={3}
          className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-xl text-white resize-none"
        />
      </div>

      <div>
        <h3 className="font-bold text-white mb-4">Business Information</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-gray-300 mb-2">Company</label>
            <input
              type="text"
              value={profile.company}
              onChange={(e) => setProfile({ ...profile, company: e.target.value })}
              className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-xl text-white"
            />
          </div>
          <div>
            <label className="block text-sm text-gray-300 mb-2">Website</label>
            <input
              type="url"
              value={profile.website}
              onChange={(e) => setProfile({ ...profile, website: e.target.value })}
              className="w-full px-4 py-3 bg-neutral-800 border border-neutral-700 rounded-xl text-white"
            />
          </div>
        </div>
      </div>

      <button
        onClick={() => handleSave('profile')}
        className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-medium py-3 px-8 rounded-full transition-all duration-300"
      >
        Save Changes
      </button>
    </div>
  );

  const renderNotifications = () => (
    <div className="space-y-6">
      <div>
        <h3 className="font-bold text-white mb-4">Email Notifications</h3>
        <div className="space-y-4">
          {Object.entries(notifications).map(([key, value]) => (
            <div key={key} className="flex justify-between items-center py-3 border-b border-neutral-800">
              <div>
                <div className="font-medium text-white capitalize">
                  {key.replace(/([A-Z])/g, ' $1').trim()}
                </div>
                <div className="text-sm text-gray-400">
                  {key === 'projectUpdates' && 'Get notified about project progress and milestones'}
                  {key === 'newOffers' && 'Receive alerts when talent submit proposals'}
                  {key === 'messages' && 'Get notified of new chat messages'}
                  {key === 'marketing' && 'Receive product updates and promotions'}
                  {key === 'weeklyDigest' && 'Weekly summary of your projects and activity'}
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={value}
                  onChange={(e) => setNotifications({ ...notifications, [key]: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-neutral-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-cyan-500"></div>
              </label>
            </div>
          ))}
        </div>
      </div>

      <button
        onClick={() => handleSave('notifications')}
        className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-medium py-3 px-8 rounded-full transition-all duration-300"
      >
        Save Preferences
      </button>
    </div>
  );

  const renderPayments = () => (
    <div className="space-y-6">
      <div>
        <h3 className="font-bold text-white mb-4">Payment Methods</h3>
        <div className="space-y-3">
          {paymentMethods.map((method) => (
            <div key={method.id} className="bg-neutral-800 p-4 rounded-xl border border-neutral-700">
              <div className="flex justify-between items-center">
                <div className="flex items-center gap-3">
                  {method.type === 'crypto' ? (
                    <Wallet className="w-5 h-5 text-purple-400" />
                  ) : (
                    <CreditCard className="w-5 h-5 text-gray-400" />
                  )}
                  <div>
                    <div className="font-medium text-white">
                      {method.type === 'crypto' ? (
                        <>
                          {method.currency} Wallet
                          <span className="text-sm text-gray-400 ml-2">
                            {method.address.slice(0, 6)}...{method.address.slice(-4)}
                          </span>
                        </>
                      ) : (
                        `${method.brand} ending in ${method.last4}`
                      )}
                    </div>
                    <div className="text-xs text-gray-400">
                      {method.type === 'crypto' && `Balance: ${method.balance} ${method.currency}`}
                      {method.default && (
                        <span className="text-cyan-400 ml-2">• Default</span>
                      )}
                    </div>
                  </div>
                </div>
                <div className="flex gap-2">
                  {method.type === 'crypto' && (
                    <button
                      onClick={() => navigator.clipboard.writeText(method.address)}
                      className="text-gray-400 hover:text-white text-sm flex items-center gap-1"
                    >
                      <Copy className="w-3 h-3" />
                      Copy
                    </button>
                  )}
                  <button className="text-gray-400 hover:text-white text-sm">Edit</button>
                  <button className="text-gray-400 hover:text-red-400 text-sm">Remove</button>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-4 flex gap-3">
          <button className="bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-white font-medium py-3 px-6 rounded-xl transition-colors">
            Add Card
          </button>
          <CryptoWallet size="md" />
        </div>
      </div>

      <div>
        <h3 className="font-bold text-white mb-4">Billing Information</h3>
        <div className="bg-neutral-800 p-4 rounded-xl border border-neutral-700">
          <div className="flex justify-between items-center mb-2">
            <span className="text-gray-400">Access Level</span>
            <span className="text-white font-medium flex items-center gap-2">
              Superintelligence Pro
              <span className="text-xs bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-500/30 text-purple-300 px-2 py-1 rounded-full">
                🧠 AI
              </span>
            </span>
          </div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-gray-400">Monthly Spend</span>
            <span className="text-white font-medium">2.45 ETH (~$4,850)</span>
          </div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-gray-400">Network Rewards</span>
            <span className="text-green-400 font-medium">+125 MXS Tokens</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-gray-400">Next Settlement</span>
            <span className="text-white font-medium">Nov 15, 2024</span>
          </div>
        </div>
      </div>
    </div>
  );

  const renderSecurity = () => (
    <div className="space-y-6">
      <div>
        <h3 className="font-bold text-white mb-4">Password & Authentication</h3>
        <div className="space-y-4">
          <button className="w-full bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-white font-medium py-3 px-4 rounded-xl transition-colors text-left flex justify-between items-center">
            <span>Change Password</span>
            <span className="text-gray-400">••••••••</span>
          </button>
          
          <div className="flex justify-between items-center py-3 border-b border-neutral-800">
            <div>
              <div className="font-medium text-white">Two-Factor Authentication</div>
              <div className="text-sm text-gray-400">Add an extra layer of security to your account</div>
            </div>
            <button className="bg-green-500 hover:bg-green-600 text-white text-sm px-4 py-2 rounded-lg">
              Enable
            </button>
          </div>
        </div>
      </div>

      <div>
        <h3 className="font-bold text-white mb-4">Login Activity</h3>
        <div className="space-y-3">
          <div className="bg-neutral-800 p-4 rounded-xl border border-neutral-700">
            <div className="flex justify-between items-start">
              <div>
                <div className="font-medium text-white">Current Session</div>
                <div className="text-sm text-gray-400">Chrome on macOS • San Francisco, CA</div>
                <div className="text-xs text-gray-500">Active now</div>
              </div>
              <span className="text-green-400 text-xs bg-green-400/10 px-2 py-1 rounded-full">Active</span>
            </div>
          </div>
          
          <div className="bg-neutral-800 p-4 rounded-xl border border-neutral-700">
            <div className="flex justify-between items-start">
              <div>
                <div className="font-medium text-white">Previous Session</div>
                <div className="text-sm text-gray-400">Safari on iPhone • San Francisco, CA</div>
                <div className="text-xs text-gray-500">2 hours ago</div>
              </div>
              <button className="text-red-400 hover:text-red-300 text-xs">Revoke</button>
            </div>
          </div>
        </div>
      </div>

      <div>
        <h3 className="font-bold text-white mb-4">Data & Privacy</h3>
        <div className="space-y-2">
          <button className="w-full bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-white font-medium py-3 px-4 rounded-xl transition-colors text-left">
            Download Your Data
          </button>
          <button className="w-full bg-red-900/20 hover:bg-red-900/30 border border-red-700 text-red-400 font-medium py-3 px-4 rounded-xl transition-colors text-left">
            Delete Account
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen px-6 py-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-white mb-2">Profile Settings</h1>
          <p className="text-gray-400">Manage your account preferences and security settings</p>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="space-y-2">
              {tabs.map((tab) => {
                const IconComponent = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-left transition-colors ${
                      activeTab === tab.id
                        ? 'bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/30 text-cyan-400'
                        : 'text-gray-400 hover:text-white hover:bg-neutral-800'
                    }`}
                  >
                    <IconComponent className="w-5 h-5" />
                    {tab.label}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Content */}
          <div className="lg:col-span-3">
            <div className="bg-neutral-900/50 border border-neutral-800 rounded-2xl p-8">
              {activeTab === 'profile' && renderProfile()}
              {activeTab === 'notifications' && renderNotifications()}
              {activeTab === 'payments' && renderPayments()}
              {activeTab === 'security' && renderSecurity()}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}