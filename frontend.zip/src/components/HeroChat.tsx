import { useState } from 'react';
import { Send, Sparkles, Zap, Target, Clock, DollarSign } from 'lucide-react';
import { AIInsights } from './AIInsights';

interface HeroChatProps {
  user: any;
  onViewTickets: () => void;
}

export function HeroChat({ user, onViewTickets }: HeroChatProps) {
  const [projectDescription, setProjectDescription] = useState('');
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [budget, setBudget] = useState('');
  const [timeline, setTimeline] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const categories = [
    { id: 'design', label: 'Design', color: 'from-pink-500 to-rose-500' },
    { id: 'development', label: 'Development', color: 'from-blue-500 to-cyan-500' },
    { id: 'marketing', label: 'Marketing', color: 'from-green-500 to-emerald-500' },
    { id: 'video', label: 'Video', color: 'from-purple-500 to-violet-500' },
    { id: 'biz', label: 'Biz', color: 'from-orange-500 to-amber-500' },
  ];

  const budgetRanges = [
    '$500 - $2K USD',
    '$2K - $5K USD',
    '$5K - $10K USD',
    '$10K - $25K USD',
    '$25K+ USD',
    '0.5 - 2 ETH',
    '2 - 5 ETH',
    '5 - 10 ETH',
    '10+ ETH',
    '10K - 50K USDC',
    '50K - 100K USDC',
    '100K+ USDC'
  ];

  const timelineOptions = [
    '1-2 weeks',
    '1 month',
    '2-3 months',
    '3-6 months',
    '6+ months'
  ];

  const toggleCategory = (categoryId: string) => {
    setSelectedCategories(prev => 
      prev.includes(categoryId)
        ? prev.filter(id => id !== categoryId)
        : [...prev, categoryId]
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!projectDescription.trim()) return;

    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsSubmitting(false);
      setProjectDescription('');
      setSelectedCategories([]);
      setBudget('');
      setTimeline('');
      onViewTickets();
    }, 2000);
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-6 py-20">
      <div className="max-w-4xl w-full">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-cyan-500/10 to-blue-500/10 border border-cyan-500/20 rounded-full px-4 py-2 mb-6">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <span className="text-cyan-300 text-sm">AI-Powered Matching</span>
          </div>
          
          <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-white via-gray-200 to-gray-400 text-transparent bg-clip-text">
            Mxstermind
          </h1>
          
          <div className="text-xl text-gray-300 mb-2">
            <span className="text-cyan-400">Describe your project.</span>{' '}
            <span>Get matched with our decentralized superintelligence network.</span>
          </div>
          
          <div className="text-sm text-gray-400 mb-4">
            🤖 AI-Powered Matching • 🌐 Decentralized Network • 💎 Crypto Native
          </div>
          
          {/* Categories */}
          <div className="flex justify-center gap-3 mt-6">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => toggleCategory(category.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all ${
                  selectedCategories.includes(category.id)
                    ? `bg-gradient-to-r ${category.color} text-white shadow-lg`
                    : 'bg-neutral-800 text-gray-400 hover:text-white hover:bg-neutral-700'
                }`}
              >
                {category.label}
              </button>
            ))}
          </div>
        </div>

        {/* Main Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Project Description */}
          <div className="relative">
            <textarea
              value={projectDescription}
              onChange={(e) => setProjectDescription(e.target.value)}
              placeholder="Describe your needs..."
              rows={4}
              className="w-full px-6 py-4 bg-neutral-900/50 border border-neutral-700 rounded-2xl text-white placeholder-gray-400 focus:ring-2 focus:ring-cyan-500 focus:border-transparent resize-none text-lg"
              required
            />
            <div className="absolute bottom-4 right-4 text-sm text-gray-500">
              {projectDescription.length}/2000
            </div>
          </div>

          {/* Budget and Timeline */}
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm text-gray-300 mb-3 flex items-center gap-2">
                <DollarSign className="w-4 h-4" />
                Budget (USD/ETH/USDC)
              </label>
              <select
                value={budget}
                onChange={(e) => setBudget(e.target.value)}
                className="w-full px-4 py-3 bg-neutral-900/50 border border-neutral-700 rounded-xl text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
              >
                <option value="">Select budget range</option>
                {budgetRanges.map((range) => (
                  <option key={range} value={range}>
                    {range}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm text-gray-300 mb-3 flex items-center gap-2">
                <Clock className="w-4 h-4" />
                Timeline
              </label>
              <select
                value={timeline}
                onChange={(e) => setTimeline(e.target.value)}
                className="w-full px-4 py-3 bg-neutral-900/50 border border-neutral-700 rounded-xl text-white focus:ring-2 focus:ring-cyan-500 focus:border-transparent"
              >
                <option value="">Select timeline</option>
                {timelineOptions.map((option) => (
                  <option key={option} value={option}>
                    {option}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button
              type="submit"
              disabled={!projectDescription.trim() || isSubmitting}
              className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-medium py-4 px-8 rounded-full transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none flex items-center gap-2 min-w-[200px] justify-center"
            >
              {isSubmitting ? (
                <>
                  <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                  Matching...
                </>
              ) : (
                <>
                  <Target className="w-5 h-5" />
                  Submit & Get Offers
                </>
              )}
            </button>

            <button
              type="button"
              onClick={onViewTickets}
              className="text-cyan-400 hover:text-cyan-300 font-medium py-4 px-6 rounded-full transition-colors border border-cyan-500/30 hover:border-cyan-500/50"
            >
              View All Tickets
            </button>
          </div>
        </form>

        {/* AI Insights */}
        {(projectDescription.length > 50 || selectedCategories.length > 0) && (
          <div className="mt-12">
            <AIInsights 
              projectData={{ description: projectDescription, categories: selectedCategories, budget, timeline }}
            />
          </div>
        )}

        {/* Quick Stats */}
        <div className="grid grid-cols-4 gap-6 mt-16 pt-8 border-t border-neutral-800">
          <div className="text-center">
            <div className="text-2xl font-bold text-cyan-400 mb-1">500+</div>
            <div className="text-gray-400 text-sm">Projects Completed</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-blue-400 mb-1">24h</div>
            <div className="text-gray-400 text-sm">AI Response Time</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-purple-400 mb-1">98%</div>
            <div className="text-gray-400 text-sm">Success Rate</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-green-400 mb-1">1,250</div>
            <div className="text-gray-400 text-sm">Network Nodes</div>
          </div>
        </div>
      </div>
    </div>
  );
}