import { Button } from "./ui/button";
import { Separator } from "./ui/separator";
import { ExternalLink, Github, Twitter, Figma } from "lucide-react";

export function Footer() {
  const footerLinks = {
    "Getting Started": [
      { label: "Tutorial", href: "#tutorial" },
      { label: "Best Practices", href: "#practices" },
      { label: "Common Pitfalls", href: "#practices" },
      { label: "Quick Reference", href: "#practices" }
    ],
    "Advanced": [
      { label: "Smart Animate", href: "#advanced" },
      { label: "Variables", href: "#advanced" },
      { label: "Components", href: "#advanced" },
      { label: "Overflow Scrolling", href: "#advanced" }
    ],
    "Resources": [
      { label: "Official Docs", href: "#resources" },
      { label: "Video Tutorials", href: "#resources" },
      { label: "Community", href: "#resources" },
      { label: "Templates", href: "#resources" }
    ]
  };

  return (
    <footer className="bg-background border-t border-border py-12 px-4">
      <div className="container mx-auto">
        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-8">
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-primary rounded flex items-center justify-center">
                <span className="text-primary-foreground font-bold">F</span>
              </div>
              <span className="font-semibold">Figma Prototyping Guide</span>
            </div>
            <p className="text-muted-foreground max-w-md">
              Master the art of prototyping in Figma. From basic interactions to advanced animations, 
              learn everything you need to create compelling user experiences.
            </p>
            <div className="flex space-x-2">
              <Button variant="ghost" size="sm">
                <Figma className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Github className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="sm">
                <Twitter className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category} className="space-y-4">
              <h4 className="font-semibold">{category}</h4>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      className="text-muted-foreground hover:text-foreground transition-colors text-sm"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <Separator className="my-8" />

        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="text-sm text-muted-foreground">
            © 2025 Figma Prototyping Guide. Built with React and Tailwind CSS.
          </div>
          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
            <a href="#" className="hover:text-foreground transition-colors">Privacy</a>
            <a href="#" className="hover:text-foreground transition-colors">Terms</a>
            <a href="#" className="hover:text-foreground transition-colors flex items-center gap-1">
              View Source <ExternalLink className="h-3 w-3" />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}