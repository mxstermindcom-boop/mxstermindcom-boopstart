
  # Prototype Mxstermind Dashboard

  This is a code bundle for Prototype Mxstermind Dashboard. The original project is available at https://www.figma.com/design/5Z7WUWETiuyJHklosDd1QY/Prototype-Mxstermind-Dashboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  