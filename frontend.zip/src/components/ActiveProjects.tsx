import { useState } from 'react';
import { Plus, Calendar, DollarSign, Users, TrendingUp, Clock, CheckCircle2 } from 'lucide-react';

interface ActiveProjectsProps {
  user: any;
  onNewChat: () => void;
}

export function ActiveProjects({ user, onNewChat }: ActiveProjectsProps) {
  const [activeProjects] = useState([
    {
      id: '1',
      title: 'E-commerce Platform Development',
      description: 'Modern React/Node.js e-commerce platform with Stripe integration',
      progress: 65,
      status: 'in-progress',
      budget: '$8,500',
      spent: '$5,525',
      deadline: new Date('2024-11-15'),
      team: [
        { name: 'Sarah Chen', role: 'Lead Developer', avatar: 'SC', active: true },
        { name: 'Mike Johnson', role: 'UI/UX Designer', avatar: 'MJ', active: false },
        { name: 'Alex Kim', role: 'Backend Developer', avatar: 'AK', active: true }
      ],
      milestones: [
        { name: 'Database Design', completed: true, date: '2024-10-01' },
        { name: 'API Development', completed: true, date: '2024-10-15' },
        { name: 'Frontend UI', completed: false, date: '2024-10-30' },
        { name: 'Payment Integration', completed: false, date: '2024-11-05' },
        { name: 'Testing & Launch', completed: false, date: '2024-11-15' }
      ],
      recentActivity: [
        { type: 'commit', message: 'Added user authentication system', time: '2 hours ago', user: 'Sarah Chen' },
        { type: 'comment', message: 'Updated the checkout flow design', time: '4 hours ago', user: 'Mike Johnson' },
        { type: 'milestone', message: 'Completed API Development milestone', time: '1 day ago', user: 'System' }
      ]
    },
    {
      id: '2', 
      title: 'Mobile App UI/UX Design',
      description: 'Fitness tracking app design with modern, clean interface',
      progress: 45,
      status: 'in-progress',
      budget: '$3,200',
      spent: '$1,440',
      deadline: new Date('2024-10-25'),
      team: [
        { name: 'Marcus Rivera', role: 'UI/UX Designer', avatar: 'MR', active: true },
        { name: 'Lisa Wong', role: 'User Research', avatar: 'LW', active: false }
      ],
      milestones: [
        { name: 'User Research', completed: true, date: '2024-09-20' },
        { name: 'Wireframes', completed: true, date: '2024-10-01' },
        { name: 'High-Fidelity Designs', completed: false, date: '2024-10-20' },
        { name: 'Prototype', completed: false, date: '2024-10-25' }
      ],
      recentActivity: [
        { type: 'design', message: 'Uploaded new workout flow designs', time: '1 hour ago', user: 'Marcus Rivera' },
        { type: 'feedback', message: 'Client approved the color palette', time: '6 hours ago', user: 'System' }
      ]
    }
  ]);

  const getDaysUntilDeadline = (deadline: Date) => {
    const now = new Date();
    const diffTime = deadline.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const getProgressColor = (progress: number) => {
    if (progress >= 80) return 'from-green-500 to-emerald-500';
    if (progress >= 50) return 'from-blue-500 to-cyan-500';
    if (progress >= 25) return 'from-yellow-500 to-orange-500';
    return 'from-red-500 to-pink-500';
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'commit': return '💻';
      case 'comment': return '💬';
      case 'milestone': return '🎯';
      case 'design': return '🎨';
      case 'feedback': return '✅';
      default: return '📝';
    }
  };

  return (
    <div className="min-h-screen px-6 py-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-2xl font-bold text-white mb-2">Active Projects</h1>
            <p className="text-gray-400">Track progress and manage ongoing collaborations</p>
          </div>
          <button
            onClick={onNewChat}
            className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-medium py-3 px-6 rounded-full transition-all duration-300 flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            New Project
          </button>
        </div>

        {/* Stats Overview */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <div className="bg-neutral-900/50 border border-neutral-800 rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-2">
              <TrendingUp className="w-5 h-5 text-green-400" />
              <span className="text-sm text-gray-400">Total Budget</span>
            </div>
            <div className="text-2xl font-bold text-white">$11,700</div>
          </div>
          
          <div className="bg-neutral-900/50 border border-neutral-800 rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-2">
              <DollarSign className="w-5 h-5 text-blue-400" />
              <span className="text-sm text-gray-400">Spent</span>
            </div>
            <div className="text-2xl font-bold text-white">$6,965</div>
          </div>
          
          <div className="bg-neutral-900/50 border border-neutral-800 rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-2">
              <Users className="w-5 h-5 text-purple-400" />
              <span className="text-sm text-gray-400">Active Talent</span>
            </div>
            <div className="text-2xl font-bold text-white">3</div>
          </div>
          
          <div className="bg-neutral-900/50 border border-neutral-800 rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-2">
              <CheckCircle2 className="w-5 h-5 text-cyan-400" />
              <span className="text-sm text-gray-400">Avg Progress</span>
            </div>
            <div className="text-2xl font-bold text-white">55%</div>
          </div>
        </div>

        {/* Active Projects */}
        <div className="space-y-8">
          {activeProjects.map((project) => (
            <div key={project.id} className="bg-neutral-900/50 border border-neutral-800 rounded-2xl p-6">
              {/* Project Header */}
              <div className="flex justify-between items-start mb-6">
                <div className="flex-1">
                  <h3 className="font-bold text-white text-lg mb-2">{project.title}</h3>
                  <p className="text-gray-400 mb-4">{project.description}</p>
                  
                  <div className="flex items-center gap-6 text-sm">
                    <div className="flex items-center gap-2 text-gray-300">
                      <DollarSign className="w-4 h-4" />
                      {project.spent} of {project.budget}
                    </div>
                    <div className="flex items-center gap-2 text-gray-300">
                      <Calendar className="w-4 h-4" />
                      {getDaysUntilDeadline(project.deadline)} days left
                    </div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-2xl font-bold text-white mb-1">{project.progress}%</div>
                  <div className="text-sm text-gray-400">Complete</div>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="mb-6">
                <div className="w-full bg-neutral-800 rounded-full h-2">
                  <div 
                    className={`h-2 rounded-full bg-gradient-to-r ${getProgressColor(project.progress)}`}
                    style={{ width: `${project.progress}%` }}
                  ></div>
                </div>
              </div>

              <div className="grid lg:grid-cols-3 gap-6">
                {/* Team */}
                <div>
                  <h4 className="font-medium text-white mb-3 flex items-center gap-2">
                    <Users className="w-4 h-4" />
                    Team
                  </h4>
                  <div className="space-y-2">
                    {project.team.map((member, index) => (
                      <div key={index} className="flex items-center gap-3">
                        <div className="relative">
                          <div className="w-8 h-8 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full flex items-center justify-center">
                            <span className="text-xs font-bold text-white">{member.avatar}</span>
                          </div>
                          {member.active && (
                            <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-green-400 border-2 border-neutral-900 rounded-full"></div>
                          )}
                        </div>
                        <div>
                          <div className="text-sm font-medium text-white">{member.name}</div>
                          <div className="text-xs text-gray-400">{member.role}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Milestones */}
                <div>
                  <h4 className="font-medium text-white mb-3 flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    Milestones
                  </h4>
                  <div className="space-y-2">
                    {project.milestones.slice(0, 4).map((milestone, index) => (
                      <div key={index} className="flex items-center gap-3">
                        <div className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                          milestone.completed 
                            ? 'bg-green-500 border-green-500' 
                            : 'border-gray-600'
                        }`}>
                          {milestone.completed && <CheckCircle2 className="w-3 h-3 text-white" />}
                        </div>
                        <div className="flex-1">
                          <div className={`text-sm ${milestone.completed ? 'text-gray-400 line-through' : 'text-white'}`}>
                            {milestone.name}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Recent Activity */}
                <div>
                  <h4 className="font-medium text-white mb-3">Recent Activity</h4>
                  <div className="space-y-3">
                    {project.recentActivity.slice(0, 3).map((activity, index) => (
                      <div key={index} className="flex gap-3">
                        <div className="text-lg">{getActivityIcon(activity.type)}</div>
                        <div className="flex-1">
                          <div className="text-sm text-gray-300">{activity.message}</div>
                          <div className="text-xs text-gray-500">{activity.time} • {activity.user}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {activeProjects.length === 0 && (
          <div className="text-center py-16">
            <div className="w-16 h-16 bg-neutral-800 rounded-full flex items-center justify-center mx-auto mb-4">
              <Clock className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="font-bold text-white mb-2">No active projects</h3>
            <p className="text-gray-400 mb-6">Start a new project to begin collaborating with talent</p>
            <button
              onClick={onNewChat}
              className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-medium py-3 px-6 rounded-full transition-all duration-300"
            >
              Create New Project
            </button>
          </div>
        )}
      </div>
    </div>
  );
}