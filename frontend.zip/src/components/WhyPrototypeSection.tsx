import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { MousePointer, Users, Zap, Layers } from "lucide-react";

export function WhyPrototypeSection() {
  const benefits = [
    {
      icon: MousePointer,
      title: "Interactive Testing",
      description: "Link screens, add transitions (dissolve, slide), and simulate real interactions like taps or hovers.",
      features: ["Click navigation", "Hover states", "Smooth transitions", "Real-time feedback"]
    },
    {
      icon: Users,
      title: "Seamless Collaboration",
      description: "Share prototypes for feedback; anyone with a link can 'play' through them and provide input.",
      features: ["Shareable links", "Comment system", "Live collaboration", "Version control"]
    },
    {
      icon: Zap,
      title: "No Extra Tools Needed",
      description: "Built-in, free for basics, and scales to advanced animations without switching platforms.",
      features: ["Free to start", "Built-in animations", "Cloud sync", "Mobile preview"]
    },
    {
      icon: Layers,
      title: "Rapid Validation",
      description: "Test user flows and validate ideas quickly without writing a single line of code.",
      features: ["Fast iteration", "User testing", "Flow validation", "Quick pivots"]
    }
  ];

  return (
    <section id="why" className="py-16 px-4 bg-muted/30">
      <div className="container mx-auto">
        <div className="text-center space-y-4 mb-12">
          <Badge variant="outline" className="mb-2">
            Why Prototype?
          </Badge>
          <h2 className="text-3xl lg:text-4xl">
            Turn Static Designs Into
            <span className="text-primary block">Interactive Experiences</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Figma prototyping bridges the gap between design and development, 
            enabling you to test and refine user experiences before building.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <Card key={index} className="group hover:shadow-lg transition-all duration-300">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                    <CardTitle className="text-xl">{benefit.title}</CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-muted-foreground">{benefit.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {benefit.features.map((feature, idx) => (
                      <Badge key={idx} variant="secondary" className="text-xs">
                        {feature}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
}