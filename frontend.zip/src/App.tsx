import { useState, useEffect } from 'react';
import { MainInterface } from './components/MainInterface';

export default function App() {
  const [user, setUser] = useState(null);

  // Auto-login for demo
  useEffect(() => {
    const mockUser = {
      id: '1',
      email: 'demo@mxstermind.com',
      name: 'Demo User',
      isTalent: false,
      whitelisted: true
    };
    setUser(mockUser);
  }, []);

  return (
    <div className="min-h-screen bg-neutral-950 text-white">
      <MainInterface user={user} />
    </div>
  );
}