import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { 
  Frame, 
  MousePointer, 
  Layers, 
  Play, 
  Sparkles, 
  Settings,
  ArrowRight,
  CheckCircle 
} from "lucide-react";

export function TutorialSection() {
  const steps = [
    {
      id: "frames",
      icon: Frame,
      title: "Set Up Frames",
      time: "2 min",
      description: "Create your design frames (Landing → Dashboard → Chat)",
      details: [
        "Use the Frame tool (F key) for mobile/desktop artboards",
        "Add elements like buttons, nav bars, and text",
        "Organize frames logically on your canvas",
        "Name frames clearly for easy navigation"
      ],
      tips: "Pro tip: Use consistent naming conventions like 'Screen_01_Landing' for better organization."
    },
    {
      id: "prototype",
      icon: MousePointer,
      title: "Switch to Prototype Mode",
      time: "1 min",
      description: "Enable prototyping and prepare for connections",
      details: [
        "Select the Prototype tab in the right sidebar",
        "Your canvas becomes a flowchart view",
        "Frames show connection points",
        "Preview mode becomes available"
      ],
      tips: "The prototype panel shows all your interactions in one place for easy management."
    },
    {
      id: "interactions",
      icon: Layers,
      title: "Add Interactions",
      time: "3 min",
      description: "Create hotspots and connect your screens",
      details: [
        "Select an element (e.g., 'Get Started' button)",
        "Drag the interaction handle to destination frame",
        "Choose action: Navigate To, Open Overlay, Swap, etc.",
        "Customize animations and timing"
      ],
      tips: "Start with simple 'Navigate To' actions before exploring overlays and complex interactions."
    },
    {
      id: "overlays",
      icon: Sparkles,
      title: "Handle Overlays & Modals",
      time: "2 min",
      description: "Create popups and modal interactions",
      details: [
        "Set interactions to 'Open Overlay'",
        "Add backdrop blur for realism",
        "Configure close triggers",
        "Position overlays correctly"
      ],
      tips: "Use overlay positioning to control where modals appear relative to the trigger element."
    },
    {
      id: "advanced",
      icon: Settings,
      title: "Advanced Features",
      time: "2 min",
      description: "Add polish with smart animations",
      details: [
        "Smart Animate: Auto-animates layer changes",
        "Variables & Conditionals for dynamic states",
        "Overflow scrolling for long content",
        "Component state management"
      ],
      tips: "Smart Animate works best when layers have identical names across frames."
    }
  ];

  return (
    <section id="tutorial" className="py-16 px-4">
      <div className="container mx-auto">
        <div className="text-center space-y-4 mb-12">
          <Badge variant="outline" className="mb-2">
            Step-by-Step Tutorial
          </Badge>
          <h2 className="text-3xl lg:text-4xl">
            Build Your First Prototype
            <span className="text-primary block">in 10 Minutes</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Follow this beginner-friendly walkthrough to create your first interactive prototype.
          </p>
        </div>

        <Tabs defaultValue="frames" className="w-full">
          <TabsList className="grid grid-cols-5 w-full mb-8">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <TabsTrigger 
                  key={step.id} 
                  value={step.id} 
                  className="flex flex-col gap-1 p-4"
                >
                  <Icon className="h-4 w-4" />
                  <span className="text-xs">{index + 1}. {step.title.split(' ')[0]}</span>
                </TabsTrigger>
              );
            })}
          </TabsList>

          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <TabsContent key={step.id} value={step.id}>
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-primary/10 rounded-lg">
                          <Icon className="h-6 w-6 text-primary" />
                        </div>
                        <div>
                          <CardTitle className="text-2xl">
                            Step {index + 1}: {step.title}
                          </CardTitle>
                          <p className="text-muted-foreground">{step.description}</p>
                        </div>
                      </div>
                      <Badge variant="outline">{step.time}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-4">
                        <h4>What to do:</h4>
                        <ul className="space-y-2">
                          {step.details.map((detail, idx) => (
                            <li key={idx} className="flex items-start gap-2">
                              <CheckCircle className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                              <span className="text-sm text-muted-foreground">{detail}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className="bg-muted/50 rounded-lg p-4">
                        <h5 className="font-medium mb-2">💡 Pro Tip</h5>
                        <p className="text-sm text-muted-foreground">{step.tips}</p>
                      </div>
                    </div>
                    
                    <div className="flex gap-3 pt-4">
                      <Button size="sm">
                        <Play className="mr-2 h-4 w-4" />
                        Try in Figma
                      </Button>
                      {index < steps.length - 1 && (
                        <Button variant="outline" size="sm">
                          Next Step
                          <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            );
          })}
        </Tabs>
      </div>
    </section>
  );
}