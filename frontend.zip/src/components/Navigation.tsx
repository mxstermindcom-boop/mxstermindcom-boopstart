import { CryptoWallet } from "./CryptoWallet";

interface NavigationProps {
  currentView: string;
  onViewChange: (view: string) => void;
  user: any;
}

export function Navigation({
  currentView,
  onViewChange,
  user,
}: NavigationProps) {
  const navItems = [
    {
      id: "chat",
      label: "New Chat",
      active: currentView === "chat",
    },
    {
      id: "tickets",
      label: "Jobs",
      active: currentView === "tickets",
    },
    {
      id: "team",
      label: "Team",
      active: currentView === "team",
    },
    {
      id: "active",
      label: "Active",
      active: currentView === "active",
    },
    {
      id: "network",
      label: "Network",
      active: currentView === "network",
    },
    {
      id: "profile",
      label: "Profile",
      active: currentView === "profile",
    },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-neutral-950/80 backdrop-blur-xl border-b border-neutral-800/50">
      <div className="max-w-6xl mx-auto px-6 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center gap-12">
            <div
              className="flex items-center gap-3 cursor-pointer"
              onClick={() => onViewChange("chat")}
            >
              <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                <span className="text-xs font-bold text-white">
                  🧠
                </span>
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-cyan-400 to-blue-500 text-transparent bg-clip-text">
                Mxstermind
              </span>
              <span className="text-xs bg-gradient-to-r from-purple-500/20 to-pink-500/20 border border-purple-500/30 text-purple-300 px-2 py-1 rounded-full">
                Superintelligence
              </span>
            </div>

            <div className="flex items-center gap-8">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => onViewChange(item.id)}
                  className={`transition-colors ${
                    item.active
                      ? "text-cyan-400"
                      : "text-gray-400 hover:text-white"
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </div>
          </div>

          {user && (
            <div className="flex items-center gap-4">
              <CryptoWallet size="sm" />
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full flex items-center justify-center">
                  <span className="text-xs font-bold text-white">
                    {user.name?.charAt(0) || "U"}
                  </span>
                </div>
                {user.isTalent && (
                  <span className="bg-purple-500/20 text-purple-300 text-xs px-2 py-1 rounded-full border border-purple-500/30">
                    AI Agent
                  </span>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </nav>
  );
}