import { useState, useEffect } from 'react';
import { Brain, TrendingUp, Target, Zap, ChevronRight, Sparkles } from 'lucide-react';

interface AIInsightsProps {
  projectData?: any;
  talents?: any[];
}

export function AIInsights({ projectData, talents }: AIInsightsProps) {
  const [insights, setInsights] = useState([]);
  const [isAnalyzing, setIsAnalyzing] = useState(true);

  useEffect(() => {
    // Simulate AI analysis
    setTimeout(() => {
      setInsights([
        {
          type: 'market',
          title: 'Market Opportunity Score',
          value: '94/100',
          description: 'High demand for this type of project in the current market',
          confidence: 0.94,
          trend: 'up',
          icon: TrendingUp,
          color: 'from-green-500 to-emerald-500'
        },
        {
          type: 'talent',
          title: 'Optimal Talent Match',
          value: '3 Perfect Matches',
          description: 'Found specialists with 95%+ skill alignment',
          confidence: 0.87,
          trend: 'up',
          icon: Target,
          color: 'from-blue-500 to-cyan-500'
        },
        {
          type: 'timeline',
          title: 'AI Predicted Timeline',
          value: '6-8 weeks',
          description: 'Based on similar projects and team velocity',
          confidence: 0.91,
          trend: 'neutral',
          icon: Zap,
          color: 'from-purple-500 to-pink-500'
        },
        {
          type: 'cost',
          title: 'Smart Cost Optimization',
          value: '12% Below Market',
          description: 'Decentralized pricing provides cost advantages',
          confidence: 0.89,
          trend: 'down',
          icon: Brain,
          color: 'from-orange-500 to-amber-500'
        }
      ]);
      setIsAnalyzing(false);
    }, 2000);
  }, [projectData, talents]);

  if (isAnalyzing) {
    return (
      <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-xl p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center animate-pulse">
            <Brain className="w-4 h-4 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-white">AI Superintelligence Analysis</h3>
            <p className="text-sm text-purple-300">Analyzing project requirements and market data...</p>
          </div>
        </div>

        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-neutral-800/50 rounded-lg p-3">
              <div className="flex items-center gap-3">
                <div className="w-3 h-3 bg-purple-400 rounded-full animate-pulse"></div>
                <div className="h-4 bg-neutral-700 rounded animate-pulse flex-1"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-xl p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
            <Brain className="w-4 h-4 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-white">AI Superintelligence Insights</h3>
            <p className="text-sm text-purple-300">Real-time analysis from our decentralized AI network</p>
          </div>
        </div>
        <div className="flex items-center gap-1 text-xs text-purple-300">
          <Sparkles className="w-3 h-3" />
          Live
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4 mb-6">
        {insights.map((insight, index) => {
          const IconComponent = insight.icon;
          return (
            <div key={index} className="bg-neutral-800/50 rounded-lg p-4">
              <div className="flex items-start justify-between mb-3">
                <div className={`w-8 h-8 bg-gradient-to-r ${insight.color} rounded-lg flex items-center justify-center`}>
                  <IconComponent className="w-4 h-4 text-white" />
                </div>
                <div className={`text-xs px-2 py-1 rounded-full ${
                  insight.confidence > 0.9 ? 'bg-green-500/20 text-green-300' :
                  insight.confidence > 0.8 ? 'bg-blue-500/20 text-blue-300' :
                  'bg-yellow-500/20 text-yellow-300'
                }`}>
                  {Math.round(insight.confidence * 100)}% confident
                </div>
              </div>
              
              <h4 className="font-medium text-white mb-1">{insight.title}</h4>
              <div className="text-lg font-bold text-white mb-2">{insight.value}</div>
              <p className="text-sm text-gray-400">{insight.description}</p>
            </div>
          );
        })}
      </div>

      <div className="bg-neutral-800/30 rounded-lg p-4">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-medium text-white mb-1">Network Recommendation</h4>
            <p className="text-sm text-gray-400">
              Based on 500+ similar projects analyzed across our decentralized network
            </p>
          </div>
          <button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 flex items-center gap-2">
            View Full Report
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}