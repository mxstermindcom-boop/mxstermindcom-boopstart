import { useState, useRef, useEffect } from 'react';
import { Send, Bot, User, Users } from 'lucide-react';

interface TicketChatProps {
  project: any;
  user: any;
}

export function TicketChat({ project, user }: TicketChatProps) {
  const [messages, setMessages] = useState(project.messages || []);
  const [newMessage, setNewMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    const userMessage = {
      role: 'user',
      text: newMessage,
      timestamp: new Date(),
      sender: user.name
    };

    setMessages(prev => [...prev, userMessage]);
    setNewMessage('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const aiResponse = {
        role: 'ai',
        text: generateAIResponse(newMessage),
        timestamp: new Date(),
        sender: 'AI Assistant'
      };
      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);

      // Sometimes simulate team member response
      if (Math.random() > 0.7) {
        setTimeout(() => {
          const teamResponse = {
            role: 'team',
            text: generateTeamResponse(newMessage),
            timestamp: new Date(),
            sender: 'Sarah (Developer)'
          };
          setMessages(prev => [...prev, teamResponse]);
        }, 2000 + Math.random() * 3000);
      }
    }, 1000 + Math.random() * 2000);
  };

  const generateAIResponse = (userMessage) => {
    const responses = [
      "I understand your requirements. Let me analyze this and provide some recommendations.",
      "That's a great point! I'll help you break this down into actionable steps.",
      "Based on your needs, I recommend exploring these technologies and approaches.",
      "I can help you with that. Let me connect you with the right talent for this task.",
      "Excellent idea! I'll create a detailed plan for implementing this feature.",
      "I see what you're looking for. Let me provide some industry best practices for this."
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  };

  const generateTeamResponse = (userMessage) => {
    const responses = [
      "I'd love to help with this! I have experience with similar projects.",
      "This looks like something I can assist with. When would you like to start?",
      "Great project! I've worked on something similar before and achieved excellent results.",
      "I'm available to take this on. Would you like to see my portfolio?",
      "This aligns perfectly with my expertise. Happy to discuss further!",
      "Interesting challenge! I have some ideas on how to approach this."
    ];
    return responses[Math.floor(Math.random() * responses.length)];
  };

  const getRoleIcon = (role) => {
    switch (role) {
      case 'ai':
        return <Bot className="w-4 h-4" />;
      case 'team':
        return <Users className="w-4 h-4" />;
      default:
        return <User className="w-4 h-4" />;
    }
  };

  const getRoleColor = (role) => {
    switch (role) {
      case 'ai':
        return 'text-pink-400';
      case 'team':
        return 'text-purple-400';
      default:
        return 'text-blue-400';
    }
  };

  const getRoleBackground = (role) => {
    switch (role) {
      case 'ai':
        return 'bg-pink-500/10 border-pink-500/20';
      case 'team':
        return 'bg-purple-500/10 border-purple-500/20';
      default:
        return 'bg-blue-500/10 border-blue-500/20';
    }
  };

  return (
    <div className="bg-neutral-800 rounded-lg border border-neutral-700">
      <div className="p-4 border-b border-neutral-700">
        <h4 className="font-medium text-white flex items-center gap-2">
          <span>Project Chat</span>
          <div className="flex -space-x-1">
            <div className="w-6 h-6 bg-pink-500 rounded-full flex items-center justify-center">
              <Bot className="w-3 h-3 text-white" />
            </div>
            <div className="w-6 h-6 bg-purple-500 rounded-full flex items-center justify-center">
              <Users className="w-3 h-3 text-white" />
            </div>
          </div>
        </h4>
      </div>

      <div className="h-64 overflow-y-auto p-4 space-y-3">
        {messages.map((message, index) => (
          <div
            key={index}
            className={`flex gap-3 ${message.role === 'user' ? 'flex-row-reverse' : ''}`}
          >
            <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${getRoleBackground(message.role)}`}>
              <span className={getRoleColor(message.role)}>
                {getRoleIcon(message.role)}
              </span>
            </div>
            <div className={`flex-1 ${message.role === 'user' ? 'text-right' : ''}`}>
              <div className="flex items-center gap-2 mb-1">
                <span className={`text-xs font-medium ${getRoleColor(message.role)}`}>
                  {message.sender || message.role}
                </span>
                <span className="text-xs text-gray-500">
                  {message.timestamp.toLocaleTimeString()}
                </span>
              </div>
              <div className={`inline-block px-3 py-2 rounded-lg max-w-xs lg:max-w-md ${
                message.role === 'user' 
                  ? 'bg-orange-500 text-white' 
                  : 'bg-neutral-700 text-gray-200'
              }`}>
                <p className="text-sm">{message.text}</p>
              </div>
            </div>
          </div>
        ))}

        {isTyping && (
          <div className="flex gap-3">
            <div className="w-8 h-8 bg-pink-500/10 border border-pink-500/20 rounded-full flex items-center justify-center">
              <Bot className="w-4 h-4 text-pink-400" />
            </div>
            <div className="bg-neutral-700 rounded-lg px-3 py-2">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSendMessage} className="p-4 border-t border-neutral-700">
        <div className="flex gap-2">
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type your message..."
            className="flex-1 px-4 py-2 bg-neutral-700 border border-neutral-600 rounded-lg text-white placeholder-gray-400 focus:ring-2 focus:ring-orange-500 focus:border-transparent"
          />
          <button
            type="submit"
            disabled={!newMessage.trim()}
            className="bg-orange-500 hover:bg-orange-600 disabled:bg-neutral-600 disabled:cursor-not-allowed text-white p-2 rounded-lg transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>
      </form>
    </div>
  );
}