import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { 
  ExternalLink, 
  BookOpen, 
  Video, 
  Users, 
  Download,
  ArrowRight,
  Star
} from "lucide-react";

export function ResourcesSection() {
  const resources = [
    {
      type: "Official Guide",
      title: "Figma's Complete Prototyping Documentation",
      description: "Comprehensive step-by-step docs with official examples and best practices.",
      icon: BookOpen,
      level: "All Levels",
      rating: 5,
      link: "#",
      category: "Documentation"
    },
    {
      type: "Interactive Tutorial",
      title: "Figma Community's Clickable Lessons",
      description: "Hands-on tutorials covering transitions, flows, and advanced interactions.",
      icon: Users,
      level: "Beginner",
      rating: 4,
      link: "#",
      category: "Tutorial"
    },
    {
      type: "Video Course",
      title: "2025 Prototyping Masterclass",
      description: "20-minute beginner tutorial covering basics to advanced techniques.",
      icon: Video,
      level: "Beginner to Advanced",
      rating: 5,
      link: "#",
      category: "Video"
    },
    {
      type: "Deep Dive",
      title: "UI Prep's Ultimate Prototyping Guide",
      description: "Advanced guide focusing on animations, components, and complex interactions.",
      icon: Download,
      level: "Advanced",
      rating: 4,
      link: "#",
      category: "Advanced"
    }
  ];

  const quickLinks = [
    { label: "Figma Help Center", href: "#" },
    { label: "Community Templates", href: "#" },
    { label: "Prototyping Plugins", href: "#" },
    { label: "Keyboard Shortcuts", href: "#" },
    { label: "Component Library", href: "#" },
    { label: "Animation Presets", href: "#" }
  ];

  return (
    <section id="resources" className="py-16 px-4 bg-muted/30">
      <div className="container mx-auto">
        <div className="text-center space-y-4 mb-12">
          <Badge variant="outline" className="mb-2">
            Learning Resources
          </Badge>
          <h2 className="text-3xl lg:text-4xl">
            Continue Your
            <span className="text-primary block">Prototyping Journey</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Explore curated resources to deepen your skills and stay updated with the latest prototyping techniques.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <h3 className="text-2xl font-semibold">Essential Resources</h3>
            <div className="grid gap-6">
              {resources.map((resource, index) => {
                const Icon = resource.icon;
                return (
                  <Card key={index} className="group hover:shadow-lg transition-all duration-300">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3">
                          <div className="p-2 bg-primary/10 rounded-lg group-hover:bg-primary/20 transition-colors">
                            <Icon className="h-5 w-5 text-primary" />
                          </div>
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <Badge variant="secondary" className="text-xs">
                                {resource.type}
                              </Badge>
                              <div className="flex items-center gap-1">
                                {[...Array(5)].map((_, i) => (
                                  <Star 
                                    key={i} 
                                    className={`h-3 w-3 ${i < resource.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'}`} 
                                  />
                                ))}
                              </div>
                            </div>
                            <CardTitle className="text-lg group-hover:text-primary transition-colors">
                              {resource.title}
                            </CardTitle>
                            <Badge variant="outline" className="text-xs">
                              {resource.level}
                            </Badge>
                          </div>
                        </div>
                        <Button variant="ghost" size="sm" className="group-hover:bg-primary/10">
                          <ExternalLink className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground mb-4">{resource.description}</p>
                      <Button size="sm" className="group">
                        Access Resource
                        <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <h3 className="text-2xl font-semibold mb-4">Quick Links</h3>
              <Card>
                <CardContent className="p-4 space-y-2">
                  {quickLinks.map((link, index) => (
                    <a
                      key={index}
                      href={link.href}
                      className="flex items-center justify-between p-2 rounded-lg hover:bg-muted/50 transition-colors group"
                    >
                      <span className="text-sm">{link.label}</span>
                      <ExternalLink className="h-3 w-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </a>
                  ))}
                </CardContent>
              </Card>
            </div>

            <Card className="overflow-hidden">
              <CardHeader>
                <CardTitle className="text-lg">Community Showcase</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <ImageWithFallback
                  src="https://images.unsplash.com/photo-1718220216044-006f43e3a9b1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xsYWJvcmF0aXZlJTIwZGVzaWduJTIwd29ya3NwYWNlfGVufDF8fHx8MTc1OTM2MjI5MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                  alt="Collaborative design workspace"
                  className="w-full h-32 object-cover"
                />
                <div className="p-4 space-y-3">
                  <p className="text-sm text-muted-foreground">
                    Explore amazing prototypes created by the community and get inspired for your next project.
                  </p>
                  <Button size="sm" variant="outline" className="w-full">
                    Browse Community
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-primary/5 border-primary/20">
              <CardHeader>
                <CardTitle className="text-lg">Ready to Start?</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  Jump into Figma and start prototyping your Mxstermind dashboard or any other project you have in mind.
                </p>
                <Button className="w-full">
                  Open Figma
                  <ExternalLink className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}