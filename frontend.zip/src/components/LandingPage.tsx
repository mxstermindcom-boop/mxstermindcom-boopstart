import { ArrowRight, Zap, Users, MessageCircle, Shield } from 'lucide-react';

interface LandingPageProps {
  onGetStarted: () => void;
}

export function LandingPage({ onGetStarted }: LandingPageProps) {
  return (
    <div className="min-h-screen bg-neutral-950">
      {/* Hero Section */}
      <section className="flex flex-col items-center justify-center py-24 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-6xl font-extrabold mb-8 bg-gradient-to-r from-orange-400 to-pink-600 text-transparent bg-clip-text">
            Build Your Empire with Human Expertise
          </h1>
          <p className="text-xl max-w-2xl mx-auto mb-8 text-gray-300 leading-relaxed">
            Bring your ideas to life, collaborate with elite talents, and launch projects with real-time support. 
            No risk, all reward.
          </p>
          <button
            onClick={onGetStarted}
            className="bg-gradient-to-r from-orange-500 to-pink-600 hover:from-orange-600 hover:to-pink-700 text-white font-bold py-4 px-8 rounded-full transition-all duration-300 transform hover:scale-105 flex items-center gap-2 mx-auto"
          >
            Get Started
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-6 bg-neutral-900/50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-16 text-white">
            Why Choose mxstermind?
          </h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="bg-neutral-800 p-8 rounded-xl border border-neutral-700 hover:border-orange-500/50 transition-colors">
              <div className="w-12 h-12 bg-gradient-to-r from-orange-500 to-pink-600 rounded-lg flex items-center justify-center mb-6">
                <Zap className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-4 text-white">Lightning Fast</h3>
              <p className="text-gray-400">
                Get your projects started instantly with our streamlined workflow and expert team.
              </p>
            </div>

            <div className="bg-neutral-800 p-8 rounded-xl border border-neutral-700 hover:border-orange-500/50 transition-colors">
              <div className="w-12 h-12 bg-gradient-to-r from-purple-500 to-pink-600 rounded-lg flex items-center justify-center mb-6">
                <Users className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-4 text-white">Elite Talent Network</h3>
              <p className="text-gray-400">
                Work with pre-vetted, whitelisted professionals who deliver exceptional results.
              </p>
            </div>

            <div className="bg-neutral-800 p-8 rounded-xl border border-neutral-700 hover:border-orange-500/50 transition-colors">
              <div className="w-12 h-12 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center mb-6">
                <MessageCircle className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-4 text-white">AI-Powered Chat</h3>
              <p className="text-gray-400">
                Get instant support with our AI assistant and seamless team communication.
              </p>
            </div>

            <div className="bg-neutral-800 p-8 rounded-xl border border-neutral-700 hover:border-orange-500/50 transition-colors">
              <div className="w-12 h-12 bg-gradient-to-r from-green-500 to-blue-600 rounded-lg flex items-center justify-center mb-6">
                <Shield className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold mb-4 text-white">Zero Risk</h3>
              <p className="text-gray-400">
                Protected projects with milestone-based payments and quality guarantees.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-16 text-white">How It Works</h2>
          
          <div className="grid md:grid-cols-3 gap-12">
            <div className="space-y-4">
              <div className="w-16 h-16 bg-gradient-to-r from-orange-500 to-pink-600 rounded-full flex items-center justify-center mx-auto">
                <span className="text-2xl font-bold text-white">1</span>
              </div>
              <h3 className="text-xl font-bold text-white">Create Your Project</h3>
              <p className="text-gray-400">
                Describe your vision and requirements. Our system creates a project ticket instantly.
              </p>
            </div>

            <div className="space-y-4">
              <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-pink-600 rounded-full flex items-center justify-center mx-auto">
                <span className="text-2xl font-bold text-white">2</span>
              </div>
              <h3 className="text-xl font-bold text-white">Get Expert Support</h3>
              <p className="text-gray-400">
                Chat with AI and connect with our whitelisted talent network for personalized assistance.
              </p>
            </div>

            <div className="space-y-4">
              <div className="w-16 h-16 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full flex items-center justify-center mx-auto">
                <span className="text-2xl font-bold text-white">3</span>
              </div>
              <h3 className="text-xl font-bold text-white">Launch & Scale</h3>
              <p className="text-gray-400">
                Receive proposals, collaborate in real-time, and launch your project with confidence.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-6 bg-gradient-to-r from-orange-500/10 to-pink-600/10">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-4xl font-bold mb-6 text-white">
            Ready to Build Your Empire?
          </h2>
          <p className="text-xl mb-8 text-gray-300">
            Join thousands of entrepreneurs who've turned their ideas into reality.
          </p>
          <button
            onClick={onGetStarted}
            className="bg-gradient-to-r from-orange-500 to-pink-600 hover:from-orange-600 hover:to-pink-700 text-white font-bold py-4 px-12 rounded-full transition-all duration-300 transform hover:scale-105"
          >
            Start Your Project Today
          </button>
        </div>
      </section>
    </div>
  );
}