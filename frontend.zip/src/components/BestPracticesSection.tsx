import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Alert, AlertDescription } from "./ui/alert";
import { 
  Lightbulb, 
  Smartphone, 
  AlertTriangle, 
  CheckCircle,
  Target,
  Layers
} from "lucide-react";

export function BestPracticesSection() {
  const practices = [
    {
      category: "Getting Started",
      icon: Target,
      color: "bg-blue-500/10 text-blue-600",
      tips: [
        "Start with linear flows (one path) before adding branches",
        "Focus on core user journeys first",
        "Keep initial prototypes simple and focused",
        "Test basic interactions before adding complexity"
      ]
    },
    {
      category: "Design Consistency",
      icon: Layers,
      color: "bg-green-500/10 text-green-600",
      tips: [
        "Ensure layers match exactly for smooth Smart Animate",
        "Use consistent naming conventions across frames",
        "Maintain visual hierarchy throughout flows",
        "Keep interaction patterns consistent"
      ]
    },
    {
      category: "Responsive Design",
      icon: Smartphone,
      color: "bg-purple-500/10 text-purple-600",
      tips: [
        "Use Auto Layout for elements that adapt on resize",
        "Test prototypes on multiple device sizes",
        "Consider touch targets for mobile interactions",
        "Plan for both portrait and landscape orientations"
      ]
    },
    {
      category: "Performance",
      icon: Lightbulb,
      color: "bg-orange-500/10 text-orange-600",
      tips: [
        "Avoid over-animating - focus on feel, not flash",
        "Use appropriate easing for natural motion",
        "Keep frame counts reasonable for smooth playback",
        "Optimize large images before prototyping"
      ]
    }
  ];

  const commonPitfalls = [
    {
      problem: "Smart Animate not working",
      solution: "Ensure layer names match exactly between frames"
    },
    {
      problem: "Slow prototype performance",
      solution: "Reduce frame complexity and optimize images"
    },
    {
      problem: "Broken interaction flows",
      solution: "Test each interaction individually before combining"
    },
    {
      problem: "Inconsistent animations",
      solution: "Standardize timing and easing across similar interactions"
    }
  ];

  return (
    <section id="practices" className="py-16 px-4">
      <div className="container mx-auto">
        <div className="text-center space-y-4 mb-12">
          <Badge variant="outline" className="mb-2">
            Best Practices
          </Badge>
          <h2 className="text-3xl lg:text-4xl">
            Build Better Prototypes
            <span className="text-primary block">with Pro Tips</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Learn from common mistakes and follow proven practices to create polished, professional prototypes.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          <div className="space-y-6">
            <h3 className="text-2xl font-semibold">Essential Guidelines</h3>
            {practices.map((practice, index) => {
              const Icon = practice.icon;
              return (
                <Card key={index} className="group hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center gap-3">
                      <div className={`p-2 rounded-lg ${practice.color}`}>
                        <Icon className="h-5 w-5" />
                      </div>
                      <CardTitle className="text-lg">{practice.category}</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {practice.tips.map((tip, tipIndex) => (
                        <li key={tipIndex} className="flex items-start gap-2">
                          <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                          <span className="text-sm text-muted-foreground">{tip}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          <div className="space-y-6">
            <h3 className="text-2xl font-semibold">Common Pitfalls to Avoid</h3>
            <div className="space-y-4">
              {commonPitfalls.map((pitfall, index) => (
                <Alert key={index} className="border-orange-200 bg-orange-50 dark:border-orange-800 dark:bg-orange-950/20">
                  <AlertTriangle className="h-4 w-4 text-orange-600" />
                  <AlertDescription className="space-y-2">
                    <div>
                      <strong className="text-orange-800 dark:text-orange-200">Problem:</strong> {pitfall.problem}
                    </div>
                    <div>
                      <strong className="text-green-800 dark:text-green-200">Solution:</strong> {pitfall.solution}
                    </div>
                  </AlertDescription>
                </Alert>
              ))}
            </div>

            <Card className="bg-primary/5 border-primary/20">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Lightbulb className="h-5 w-5 text-primary" />
                  Pro Tip of the Day
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Start your prototyping process by mapping out the entire user journey on paper or a whiteboard. 
                  This helps you identify the key screens and interactions before diving into Figma, 
                  saving time and ensuring a more coherent final prototype.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-muted/50">
              <CardHeader>
                <CardTitle className="text-lg">Quick Reference</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <strong>Keyboard Shortcuts:</strong>
                    <ul className="mt-1 space-y-1 text-muted-foreground">
                      <li>F - Frame tool</li>
                      <li>R - Rectangle tool</li>
                      <li>T - Text tool</li>
                      <li>Space + drag - Pan canvas</li>
                    </ul>
                  </div>
                  <div>
                    <strong>Animation Timing:</strong>
                    <ul className="mt-1 space-y-1 text-muted-foreground">
                      <li>Micro: 100-200ms</li>
                      <li>Standard: 300-500ms</li>
                      <li>Complex: 500-800ms</li>
                      <li>Page transitions: 300ms</li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}