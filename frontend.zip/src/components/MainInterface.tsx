import { useState } from 'react';
import { Navigation } from './Navigation';
import { HeroChat } from './HeroChat';
import { RecentTickets } from './RecentTickets';
import { ActiveProjects } from './ActiveProjects';
import { TeamHub } from './TeamHub';
import { ProfileSettings } from './ProfileSettings';
import { DecentralizedFeatures } from './DecentralizedFeatures';

interface MainInterfaceProps {
  user: any;
}

export function MainInterface({ user }: MainInterfaceProps) {
  const [currentView, setCurrentView] = useState('chat');
  const [showDecentralizedInfo, setShowDecentralizedInfo] = useState(false);

  const renderContent = () => {
    switch (currentView) {
      case 'chat':
        return <HeroChat user={user} onViewTickets={() => setCurrentView('tickets')} />;
      case 'tickets':
        return <RecentTickets user={user} onNewChat={() => setCurrentView('chat')} />;
      case 'active':
        return <ActiveProjects user={user} onNewChat={() => setCurrentView('chat')} />;
      case 'team':
        return <TeamHub user={user} />;
      case 'profile':
        return <ProfileSettings user={user} />;
      case 'network':
        return <DecentralizedFeatures />;
      default:
        return <HeroChat user={user} onViewTickets={() => setCurrentView('tickets')} />;
    }
  };

  return (
    <div className="min-h-screen">
      <Navigation 
        currentView={currentView} 
        onViewChange={setCurrentView}
        user={user}
      />
      <main className="pt-16">
        {renderContent()}
      </main>
    </div>
  );
}