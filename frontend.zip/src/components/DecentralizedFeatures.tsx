import { useState } from 'react';
import { Shield, Globe, Zap, Award, ChevronRight, ExternalLink } from 'lucide-react';

export function DecentralizedFeatures() {
  const [activeFeature, setActiveFeature] = useState('governance');

  const features = [
    {
      id: 'governance',
      title: 'DAO Governance',
      icon: Shield,
      color: 'from-blue-500 to-cyan-500',
      description: 'Community-driven decisions through decentralized voting',
      details: [
        'Token holders vote on platform improvements',
        'Transparent proposal and execution process',
        'Decentralized dispute resolution system',
        'Community treasury management'
      ]
    },
    {
      id: 'network',
      title: 'Global Network',
      icon: Globe,
      color: 'from-green-500 to-emerald-500',
      description: 'Distributed network of AI agents and human talent',
      details: [
        '1,250+ active network nodes worldwide',
        'Real-time talent matching across continents',
        'Redundant AI processing for 99.9% uptime',
        'Cross-border payments in crypto'
      ]
    },
    {
      id: 'rewards',
      title: 'Token Rewards',
      icon: Award,
      color: 'from-purple-500 to-pink-500',
      description: 'Earn MXS tokens for platform participation',
      details: [
        'Talent earns tokens for high-quality work',
        'Clients earn rewards for successful projects',
        'Validators earn fees for dispute resolution',
        'Staking rewards for network security'
      ]
    },
    {
      id: 'smart-contracts',
      title: 'Smart Contracts',
      icon: Zap,
      color: 'from-orange-500 to-amber-500',
      description: 'Automated payments and milestone tracking',
      details: [
        'Escrow payments released automatically',
        'Milestone-based smart contract execution',
        'Dispute resolution through DAO voting',
        'Cross-chain compatibility (ETH, SOL, POLY)'
      ]
    }
  ];

  const stats = [
    { label: 'Total Value Locked', value: '12.5M', unit: 'USDC' },
    { label: 'Network Nodes', value: '1,250', unit: 'Active' },
    { label: 'MXS Token Holders', value: '8,900', unit: 'Holders' },
    { label: 'Smart Contracts', value: '2,340', unit: 'Deployed' }
  ];

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h2 className="text-2xl font-bold text-white mb-4">
          Decentralized Superintelligence Network
        </h2>
        <p className="text-gray-400 max-w-2xl mx-auto">
          Powered by blockchain technology and AI, creating a trustless ecosystem for 
          global talent collaboration and project delivery.
        </p>
      </div>

      {/* Stats */}
      <div className="grid md:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <div key={index} className="bg-neutral-900/50 border border-neutral-800 rounded-xl p-4 text-center">
            <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
            <div className="text-sm text-gray-400">{stat.label}</div>
            <div className="text-xs text-cyan-400">{stat.unit}</div>
          </div>
        ))}
      </div>

      {/* Feature Tabs */}
      <div className="grid lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1">
          <div className="space-y-2">
            {features.map((feature) => {
              const IconComponent = feature.icon;
              return (
                <button
                  key={feature.id}
                  onClick={() => setActiveFeature(feature.id)}
                  className={`w-full flex items-center gap-3 p-4 rounded-xl text-left transition-all ${
                    activeFeature === feature.id
                      ? `bg-gradient-to-r ${feature.color} bg-opacity-20 border border-opacity-30`
                      : 'bg-neutral-800 hover:bg-neutral-700 border border-neutral-700'
                  }`}
                  style={{
                    borderColor: activeFeature === feature.id ? 'rgba(59, 130, 246, 0.3)' : undefined
                  }}
                >
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center bg-gradient-to-r ${feature.color}`}>
                    <IconComponent className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <div className="font-medium text-white">{feature.title}</div>
                    <div className="text-xs text-gray-400">{feature.description}</div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        <div className="lg:col-span-3">
          {features.map((feature) => {
            if (feature.id !== activeFeature) return null;
            const IconComponent = feature.icon;
            
            return (
              <div key={feature.id} className="bg-neutral-900/50 border border-neutral-800 rounded-xl p-8">
                <div className="flex items-center gap-4 mb-6">
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center bg-gradient-to-r ${feature.color}`}>
                    <IconComponent className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white">{feature.title}</h3>
                    <p className="text-gray-400">{feature.description}</p>
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4 mb-6">
                  {feature.details.map((detail, index) => (
                    <div key={index} className="flex items-center gap-3 p-3 bg-neutral-800/50 rounded-lg">
                      <div className="w-2 h-2 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full flex-shrink-0"></div>
                      <span className="text-gray-300 text-sm">{detail}</span>
                    </div>
                  ))}
                </div>

                <div className="flex gap-4">
                  <button className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-medium py-3 px-6 rounded-lg transition-all duration-300 flex items-center gap-2">
                    Learn More
                    <ChevronRight className="w-4 h-4" />
                  </button>
                  <button className="bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-white font-medium py-3 px-6 rounded-lg transition-colors flex items-center gap-2">
                    Documentation
                    <ExternalLink className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Token Info */}
      <div className="bg-gradient-to-r from-purple-500/10 to-pink-500/10 border border-purple-500/30 rounded-xl p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-bold text-white mb-2">MXS Token Utility</h3>
            <p className="text-gray-400">The native token powering our decentralized network</p>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-white">$2.45</div>
            <div className="text-sm text-green-400">+12.5% (24h)</div>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          <div className="bg-neutral-800/50 p-4 rounded-lg">
            <h4 className="font-medium text-white mb-2">Governance</h4>
            <p className="text-sm text-gray-400">Vote on proposals and network upgrades</p>
          </div>
          <div className="bg-neutral-800/50 p-4 rounded-lg">
            <h4 className="font-medium text-white mb-2">Staking</h4>
            <p className="text-sm text-gray-400">Earn rewards for securing the network</p>
          </div>
          <div className="bg-neutral-800/50 p-4 rounded-lg">
            <h4 className="font-medium text-white mb-2">Payments</h4>
            <p className="text-sm text-gray-400">Pay for services with reduced fees</p>
          </div>
        </div>
      </div>
    </div>
  );
}