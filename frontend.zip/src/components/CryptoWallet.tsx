import { useState } from 'react';
import { Wallet, Check, ExternalLink, Copy } from 'lucide-react';

interface CryptoWalletProps {
  onConnect?: (wallet: any) => void;
  size?: 'sm' | 'md' | 'lg';
}

export function CryptoWallet({ onConnect, size = 'md' }: CryptoWalletProps) {
  const [isConnected, setIsConnected] = useState(false);
  const [selectedWallet, setSelectedWallet] = useState(null);
  const [showWallets, setShowWallets] = useState(false);

  const wallets = [
    {
      id: 'metamask',
      name: 'MetaMask',
      icon: '🦊',
      description: 'Connect using MetaMask wallet'
    },
    {
      id: 'coinbase',
      name: 'Coinbase Wallet',
      icon: '🔵',
      description: 'Connect using Coinbase Wallet'
    },
    {
      id: 'walletconnect',
      name: 'WalletConnect',
      icon: '🔗',
      description: 'Connect with WalletConnect'
    },
    {
      id: 'phantom',
      name: 'Phantom',
      icon: '👻',
      description: 'Connect using Phantom (Solana)'
    }
  ];

  const mockBalance = {
    eth: '2.45',
    usdc: '12,450',
    usd: '8,245'
  };

  const mockAddress = '0x742d35Cc6234C3F4AF7b8c7d5c02F8e123456789';

  const handleWalletConnect = (wallet) => {
    // Simulate wallet connection
    setTimeout(() => {
      setSelectedWallet(wallet);
      setIsConnected(true);
      setShowWallets(false);
      
      const walletData = {
        ...wallet,
        address: mockAddress,
        balance: mockBalance
      };
      
      onConnect?.(walletData);
    }, 1000);
  };

  const copyAddress = () => {
    navigator.clipboard.writeText(mockAddress);
  };

  const getSizeClasses = () => {
    switch (size) {
      case 'sm':
        return 'px-3 py-2 text-sm';
      case 'lg':
        return 'px-6 py-4 text-lg';
      default:
        return 'px-4 py-3';
    }
  };

  if (isConnected && selectedWallet) {
    return (
      <div className="bg-gradient-to-r from-green-500/10 to-emerald-500/10 border border-green-500/30 rounded-xl p-4">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-green-500/20 rounded-full flex items-center justify-center">
              <span className="text-lg">{selectedWallet.icon}</span>
            </div>
            <div>
              <div className="font-medium text-white">{selectedWallet.name}</div>
              <div className="text-sm text-green-400">Connected</div>
            </div>
          </div>
          <Check className="w-5 h-5 text-green-400" />
        </div>

        <div className="space-y-2 mb-4">
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">ETH Balance</span>
            <span className="text-white font-medium">{mockBalance.eth} ETH</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">USDC Balance</span>
            <span className="text-white font-medium">{mockBalance.usdc} USDC</span>
          </div>
          <div className="flex justify-between text-sm">
            <span className="text-gray-400">Total Value</span>
            <span className="text-white font-medium">${mockBalance.usd}</span>
          </div>
        </div>

        <div className="flex items-center gap-2 p-2 bg-neutral-800 rounded-lg">
          <span className="text-xs text-gray-400 flex-1 font-mono">
            {mockAddress.slice(0, 6)}...{mockAddress.slice(-4)}
          </span>
          <button
            onClick={copyAddress}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <Copy className="w-3 h-3" />
          </button>
          <button className="text-gray-400 hover:text-white transition-colors">
            <ExternalLink className="w-3 h-3" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative">
      <button
        onClick={() => setShowWallets(!showWallets)}
        className={`bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-medium rounded-xl transition-all duration-300 flex items-center gap-2 ${getSizeClasses()}`}
      >
        <Wallet className="w-4 h-4" />
        Connect Wallet
      </button>

      {showWallets && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-neutral-900 border border-neutral-700 rounded-xl p-4 z-50 min-w-[300px]">
          <h3 className="font-medium text-white mb-3">Connect your wallet</h3>
          <div className="space-y-2">
            {wallets.map((wallet) => (
              <button
                key={wallet.id}
                onClick={() => handleWalletConnect(wallet)}
                className="w-full flex items-center gap-3 p-3 bg-neutral-800 hover:bg-neutral-700 rounded-lg transition-colors text-left"
              >
                <span className="text-2xl">{wallet.icon}</span>
                <div>
                  <div className="font-medium text-white">{wallet.name}</div>
                  <div className="text-sm text-gray-400">{wallet.description}</div>
                </div>
              </button>
            ))}
          </div>
          
          <div className="mt-4 p-3 bg-blue-500/10 border border-blue-500/30 rounded-lg">
            <p className="text-xs text-blue-300">
              🔐 Your wallet connection is secure and encrypted. We never store your private keys.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}